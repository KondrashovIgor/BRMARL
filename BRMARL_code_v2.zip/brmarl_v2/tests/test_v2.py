import json, copy, pickle
from pathlib import Path
import numpy as np
import torch
import pytest
from brmarl.config import MarketConfig, AgentConfig, ParallelConfig
from brmarl.data import (
    make_fixture_assets,
    prepare_route_cache,
    create_search_index,
    merge_route_deltas,
    prewarm_centroid_pool,
)
from brmarl.cache import SecondsRouter, coord_key
from brmarl.agent import BRMARLAgent
from brmarl.inference import NeuralBatcher
from brmarl.environment import Market
from brmarl.routing import FixtureRouter
from brmarl.models import D
from brmarl.experiment import train, load_checkpoint


def test_original_count_385_and_directed_legacy_ids(tmp_path):
    assert MarketConfig().expected_original_polygons == 385
    raw = np.memmap(tmp_path / "distances.dat", mode="w+", dtype=np.int32, shape=(3, 3))
    raw[:] = [[20, 70, 15], [70, 20, 27], [70, 99, 10**9]]
    raw.flush()
    idx = create_search_index(raw, chunk_rows=2)
    assert idx == {20: (0, 1), 70: (1, 3)}
    data = make_fixture_assets(tmp_path / "fixture.json")
    a, b = data["home_points"][:2]
    spec = prepare_route_cache(
        data, tmp_path / "cache", raw, idx, {tuple(a): 20, tuple(b): 70}, fixture=True
    )
    r = SecondsRouter(spec)
    assert r.route(a, b, False).seconds == 15
    assert r.route(b, a, False).seconds == 27
    assert r.stats()["counts"]["legacy_memmap"] == 2
    assert not r.stats()["counts"].get("fallback_calls", 0)
    r.close()


def test_separate_centroid_directions_persist_and_missing_falls_back(tmp_path):
    data = make_fixture_assets(tmp_path / "fixture.json")
    spec = prepare_route_cache(data, tmp_path / "cache", fixture=True)
    s = json.loads(Path(spec).read_text())
    f = np.load(s["forward_path"], mmap_mode="r+")
    b = np.load(s["reverse_path"], mmap_mode="r+")
    f[0, 0] = 11
    b[0, 0] = 42
    f.flush()
    b.flush()
    r = SecondsRouter(spec)
    a, c = s["orders"][0], s["centroids"][0]
    assert r.route(c, a, False).seconds == 11 and r.route(a, c, False).seconds == 42
    unknown = (a[0] + 0.001, a[1] + 0.001)
    first = r.route(unknown, c, False).seconds
    assert r.route(unknown, c, False).seconds == first
    assert r.stats()["counts"]["fallback_calls"] == 1
    r.close()
    merge_route_deltas(spec)
    assert Path(spec).with_name("route_additions.jsonl").is_file()


def test_prewarm_selected_pool_not_whole_map(tmp_path):
    data = make_fixture_assets(tmp_path / "fixture.json")
    spec = prepare_route_cache(data, tmp_path / "cache", fixture=True)
    prewarm_centroid_pool(spec, [0], [0, 2], reverse=True, progress=False)
    s = json.loads(Path(spec).read_text())
    a = np.load(s["forward_path"])
    assert np.isfinite(a[0, [0, 2]]).all() and np.isnan(a[1]).all()


def test_batch_inference_equals_scalar_without_mcd_noise(tmp_path):
    cfg = MarketConfig(n_couriers=3)
    ac = AgentConfig(dropout=0)
    a = BRMARLAgent(0, ac, cfg)
    engine = NeuralBatcher([a], "cpu")
    rng = np.random.default_rng(2)
    requests = [
        {
            "agent": 0,
            "x": rng.normal(size=D).astype("f"),
            "previous": np.zeros(ac.hidden, "f"),
            "opponents": rng.normal(size=(2, 5)).astype("f"),
            "latent": np.zeros(ac.hidden, "f"),
            "memory": np.ones(ac.modes, "f") * 0.5,
            "prototype": None,
            "cfr_count": 0,
        }
        for _ in range(4)
    ]
    actual = engine.infer_many(requests)
    single = [engine.infer_many([r])[0] for r in requests]
    for x, y in zip(actual, single):
        for k in ("context", "alpha", "beta", "atom", "rho", "hidden", "spatial"):
            assert np.allclose(x[k], y[k], atol=2e-6)


def test_busy_shadows_stay_at_departure_anchor(tmp_path):
    cfg = MarketConfig(B=3600, n_couriers=1, target_new_orders=8, cap_new_orders=8)
    assets = make_fixture_assets(tmp_path / "fixture.json")
    a = BRMARLAgent(0, AgentConfig(), cfg)
    env = Market(assets, FixtureRouter(), [a], cfg)
    c = env.couriers[0]
    anchor = c.position
    c.status = "working"
    c.busy_until = 1000
    c.segments = [(0, 1000, FixtureRouter().route(anchor, assets["home_points"][20]))]
    c.locate(500)
    assert c.position == anchor and not c.available(500, cfg.B)


def test_packet_barrier_and_independent_versions(tmp_path):
    cfg = MarketConfig(
        B=600,
        n_couriers=3,
        target_new_orders=4,
        cap_new_orders=4,
        expected_original_polygons=None,
        expected_order_points=None,
        break_probability_enabled=False,
    )
    ac = AgentConfig(model_adv_weight=0.0, context_epochs=1)
    assets = make_fixture_assets(tmp_path / "fixture.json")
    par = ParallelConfig(workers=2, markets_per_batch=4, device="cpu", progress=False)
    agents, summary = train(
        assets,
        cfg,
        ac,
        n_batches=2,
        output=tmp_path / "out",
        parallel_cfg=par,
        fixture=True,
    )
    assert summary["shift"].nunique() == 8 and all(a.version == 2 for a in agents)
    for p in (tmp_path / "out").glob("batch_*/shift_*/worker_timing.json"):
        m = json.loads(p.read_text())
        assert m["adapter_updates_during_rollout"] == 0 and m["barrier_wait_s"] >= 0
    for p in (tmp_path / "out").glob("batch_*/batch_timing.json"):
        m = json.loads(p.read_text())
        assert m["markets"] == 4 and m["observations"] > 0
        assert all(
            r.get("max_behavior_logprob_error", 0) < 1e-3 for r in m["agent_updates"]
        )
    saved = load_checkpoint(tmp_path / "out/checkpoint.pt", assets)
    assert saved["n_training_shifts"] == 8 and saved["n_training_batches"] == 2
    assert all(next(a.model.parameters()).device.type == "cpu" for a in saved["agents"])


def test_exactly_21_cost_lookups_for_ten_couriers(tmp_path):
    from brmarl.sampling import sample_order

    cfg = MarketConfig(n_couriers=10)
    data = make_fixture_assets(tmp_path / "fixture.json")

    class CountingRouter(FixtureRouter):
        def route(self, *args, **kwargs):
            self.calls += 1
            return super().route(*args, **kwargs)

    router = CountingRouter()
    agents = [BRMARLAgent(i, AgentConfig(), cfg) for i in range(10)]
    env = Market(data, router, agents, cfg)
    o = sample_order(data, np.random.default_rng(1), cfg, "one", 0)
    assert len(env.prepare_costs([o])) == 10 and router.calls == 21


def test_route_timeout_is_logged_before_shift_end(tmp_path):
    from brmarl.routing import RoutingError

    data = make_fixture_assets(tmp_path / "fixture.json")
    spec = prepare_route_cache(data, tmp_path / "cache", fixture=True)
    r = SecondsRouter(spec)

    def failed(*args):
        raise RoutingError("timed out")

    r.fallback.route = failed
    with pytest.raises(RoutingError):
        r.route(data["home_points"][0], data["polygons"][0]["centroid"])
    assert r.error_path.exists() and r.stats()["counts"]["timeouts"] == 1
    assert "timed out" in r.error_path.read_text()
    r.close()


def test_progress_slots_reused_not_recreated(monkeypatch):
    import tqdm
    from brmarl.progress import MarketProgress

    created = []

    class Bar:
        def __init__(self, **kwargs):
            self.n = 0
            self.position = kwargs["position"]
            created.append(self)

        def reset(self, total):
            self.n = 0

        def set_description(self, desc):
            self.desc = desc

        def update(self, v):
            self.n += v

        def set_postfix(self, **kwargs):
            self.postfix = kwargs

        def close(self):
            pass

    monkeypatch.setattr(tqdm, "tqdm", Bar)
    p = MarketProgress([0, 1, 2], 43200, True)
    p.update(0, 7200)
    p.reset([12, 13, 14])
    p.update(13, 3600, "simulate")
    assert len(created) == 3 and list(p.bars) == [12, 13, 14]
    assert [b.position for b in created] == [0, 1, 2] and p.bars[13].n == 1
    p.close()


def test_resume_preserves_previous_summary_and_policy_version(tmp_path):
    cfg = MarketConfig(
        B=600,
        n_couriers=2,
        target_new_orders=4,
        cap_new_orders=4,
        expected_original_polygons=None,
        expected_order_points=None,
        break_probability_enabled=False,
    )
    data = make_fixture_assets(tmp_path / "fixture.json")
    ac = AgentConfig(context_epochs=1, model_adv_weight=0.0)
    par = ParallelConfig(workers=1, markets_per_batch=1, device="cpu", progress=False)
    out = tmp_path / "resume"
    train(data, cfg, ac, n_batches=1, output=out, parallel_cfg=par, fixture=True)
    agents, summary = train(
        data,
        cfg,
        ac,
        n_batches=1,
        output=out,
        parallel_cfg=par,
        fixture=True,
        resume=out / "checkpoint.pt",
    )
    assert summary["shift"].nunique() == 2 and all(a.version == 2 for a in agents)
    assert len(json.loads((out / "batch_timings.json").read_text())) == 2


def test_offline_price_cfr_averages_regret_policies_not_old_actor(tmp_path):
    from brmarl.costs import evaluate_cost
    from brmarl.sampling import sample_order

    cfg = MarketConfig(n_couriers=2)
    ac = AgentConfig(context_epochs=0)
    data = make_fixture_assets(tmp_path / "fixture.json")
    a = BRMARLAgent(0, ac, cfg)
    env = Market(data, FixtureRouter(), [a, BRMARLAgent(1, ac, cfg)], cfg)
    order = sample_order(data, np.random.default_rng(9), cfg, "cf", 0)
    cost = evaluate_cost(env.couriers[0], order, env.router, cfg)
    d = a.decide_price(env.couriers[0], order, cost, 0, env.public)
    rewards = np.zeros(ac.price_grid)
    rewards[12] = 1000
    a.bank.observe(d.key, 0.5, d.x)
    a.endshift = [(d, 0, rewards)] * 30
    a.end_shift(True)
    assert a.cfr.average_policy(d.key)[12] > 0.95
