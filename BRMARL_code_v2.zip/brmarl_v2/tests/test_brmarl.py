import copy, json
from dataclasses import replace
from pathlib import Path
import numpy as np
import pytest
import torch
from brmarl.config import MarketConfig, AgentConfig
from brmarl.data import make_fixture_assets, original_ids, export_assets, load_assets
from brmarl.sampling import (
    ArrivalProcess,
    break_duration,
    break_probability,
    reprice,
    sample_order,
)
from brmarl.routing import FixtureRouter, OSRMRouter, RoutingError, haversine
from brmarl.costs import evaluate_cost, stop_hazard
from brmarl.models import ContextModel, ThresholdBank, D
from brmarl.agent import BRMARLAgent
from brmarl.environment import Market
from brmarl.evaluation import validate_market, refusal_metrics

torch.set_num_threads(1)


def test_busy_observation_advances_memory_without_real_participation(tmp_path):
    cfg = MarketConfig(
        B=3600,
        n_couriers=1,
        target_new_orders=8,
        cap_new_orders=8,
        expected_original_polygons=None,
        expected_order_points=None,
    )
    data = make_fixture_assets(tmp_path / "fixture.json")
    a = BRMARLAgent(0, AgentConfig(), cfg)
    env = Market(data, FixtureRouter(), [a], cfg)
    c = env.couriers[0]
    c.status = "working"
    c.busy_until = 1000
    o = sample_order(data, np.random.default_rng(2), cfg, "busy-memory", 0)
    before = a.h.copy()
    weights = copy.deepcopy(a.context.state_dict())
    env.tender_batch([o])
    assert not np.allclose(a.h, before)
    assert not env.logs["decisions"][0]["selected"]
    assert env.logs["decisions"][0]["reason"] == "busy"
    assert all(torch.equal(v, a.context.state_dict()[k]) for k, v in weights.items())


@pytest.fixture
def setup_market(tmp_path):
    cfg = MarketConfig(
        B=3600,
        n_couriers=3,
        target_new_orders=30,
        cap_new_orders=30,
        expected_original_polygons=None,
        expected_order_points=None,
        break_probability_enabled=True,
    )
    ac = AgentConfig(update_every=4, min_known=2, cfr_min_count=2, context_epochs=1)
    data = make_fixture_assets(tmp_path / "fixture.json")
    agents = [BRMARLAgent(i, ac, cfg) for i in range(cfg.n_couriers)]
    return cfg, ac, data, agents


def test_original_suffix_not_confused_with_original_identifier(tmp_path):
    raw = {
        "G-35-1": {"augmented": False, "points cloud": [[55.0, 37.0], [55.01, 37.01]]},
        "AUG--AUG-G-35-1-1": {"augmented": True, "points cloud": [[0, 0]]},
    }
    assert original_ids(raw) == ["G-35-1"]
    export_assets(
        raw, {"G-35-1": {"alpha": 0.5, "beta": 0.4, "gamma": 0.1}}, tmp_path / "a.json"
    )
    assert len(load_assets(tmp_path / "a.json")["polygons"]) == 1


def test_estimated_duration_not_added_to_real_execution(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(), agents, cfg)
    o = sample_order(data, np.random.default_rng(9), cfg, "o", 0)
    cost = evaluate_cost(env.couriers[0], o, env.router, cfg)
    assert 1200 <= o.service_s <= 1800
    assert cost.execution_s == cost.travel_s
    assert cost.logistics == pytest.approx(cost.travel_s * 500 / 3600)


def test_positive_logistic_arrivals_and_rate():
    cfg = MarketConfig()
    arrival = ArrivalProcess(cfg)
    rng = np.random.default_rng(3)
    intervals = np.array([arrival.sample_interval(rng) for _ in range(20000)])
    assert intervals.min() >= 60
    assert intervals.mean() / 60 == pytest.approx(4.8, abs=0.12)
    assert sum(n for _, n in arrival.schedule(rng)) <= 300


def test_break_distribution_and_continuous_clock():
    cfg = MarketConfig()
    rng = np.random.default_rng(3)
    x = np.array([break_duration(rng, cfg) for _ in range(2000)])
    assert x.min() >= 600 and x.max() <= 1200
    assert x.mean() == pytest.approx(900, abs=12)
    assert break_probability(cfg.B / 4, cfg) == 0.5
    assert break_probability(0, cfg) < 1e-10


def test_budget_reprice_monotonic_capped():
    rng = np.random.default_rng(0)
    p = 400
    for _ in range(100):
        q = reprice(p, rng, 1800)
        assert p <= q <= 1800
        p = q


def test_stop_hazard_matches_document():
    from scipy.special import expit

    for n in [1, 5, 12, 30]:
        f = expit((n - 12) / 3)
        prev = expit((n - 1 - 12) / 3)
        assert stop_hazard(n, 12, 3) == pytest.approx((f - prev) / (1 - prev))


def test_set_encoder_permutation_invariance():
    torch.manual_seed(1)
    model = ContextModel(24, 0.15, 6).eval()
    x = torch.zeros(D)
    h = torch.zeros(24)
    opp = torch.randn(8, 5)
    a, _ = model(x, h, opp)
    b, _ = model(x, h, opp[torch.tensor([3, 1, 0, 2, 7, 4, 6, 5])])
    assert torch.allclose(a, b, atol=1e-6)


def test_threshold_cdf_is_monotone_with_inactive_mass():
    b = ThresholdBank()
    x = np.zeros(D)
    for y in [0.2, 0.3, 0.7, 1.0, float("inf")] * 20:
        b.observe(("k",), y, x, 1)
    grid = np.linspace(0, 1, 201)
    cdf = b.distributions(grid)
    assert (cdf >= 0).all() and (cdf <= 1).all()
    assert (np.diff(cdf, axis=1) >= -1e-10).all()
    assert cdf[-1, -1] < 1  # Explicit probability of a threshold above feasible U.


def test_no_hidden_preferences_in_predecision_features(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(), agents, cfg)
    o = sample_order(data, np.random.default_rng(0), cfg, "o", 0)
    c = env.couriers[0]
    cost = evaluate_cost(c, o, env.router, cfg)
    a = agents[0]
    _, x1, _ = a.features(c, o, cost, 0, env.public)
    o.theta = (0.001, 0.99, 0.009)
    _, x2, _ = a.features(c, o, cost, 0, env.public)
    assert np.array_equal(x1, x2)


def test_commitment_and_final_ledger(setup_market, tmp_path):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(speed_m_s=3), agents, cfg)
    summary = env.run()
    assert validate_market(env)["status"] == "passed"
    assert summary.completed.sum() > 0
    assert any(r["reason"] == "busy" for r in env.logs["decisions"])
    assert (
        sum(r["event"] == "return_home" for r in env.logs["ledger"]) == cfg.n_couriers
    )
    assert all(
        r["information_phase"] == "pre_participation" for r in env.logs["decisions"]
    )
    env.save(tmp_path / "logs")
    assert (tmp_path / "logs/decisions.csv").is_file()


def test_break_movement_is_inside_two_km(setup_market):
    cfg, _, data, agents = setup_market
    cfg = replace(
        cfg,
        B=600,
        break_hazard_scale_s=100,
        break_min_s=100,
        break_max_s=200,
        break_mean_s=150,
        break_std_s=30,
        target_new_orders=8,
        cap_new_orders=8,
    )
    env = Market(data, FixtureRouter(), agents, cfg)
    c = env.couriers[0]
    env.now = 200
    env.take_break(c)
    r = env.logs["movements"][-1]
    assert c.status == "break" and not c.available(201, cfg.B)
    assert haversine(r["geometry"][0], r["geometry"][-1]) <= 2000 + 1e-6
    assert 100 <= c.busy_until - env.now <= 200


def test_frozen_modules_not_updated_inside_shift(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(), agents, cfg)
    for a in agents:
        original = a.context_opt.step

        def checked(*args, _original=original, **kwargs):
            assert env.now >= cfg.B
            return _original(*args, **kwargs)

        a.context_opt.step = checked
    env.run()


def test_frozen_test_does_not_learn(setup_market):
    cfg, _, data, agents = setup_market
    before = [copy.deepcopy(a.model.state_dict()) for a in agents]
    env = Market(data, FixtureRouter(), agents, cfg, training=False)
    env.run()
    for a, weights in zip(agents, before):
        assert a.learning_steps == 0 and not a.bank.contexts
        assert all(torch.equal(v, a.model.state_dict()[k]) for k, v in weights.items())


def test_osrm_units_and_geometry_cache(tmp_path):
    router = OSRMRouter(tmp_path / "cache.sqlite", min_interval=0)
    router._get = lambda path: {
        "routes": [
            {
                "duration": 123.4,
                "distance": 987.0,
                "geometry": {"coordinates": [[37.0, 55.0], [37.01, 55.01]]},
            }
        ]
    }
    r = router.route((55, 37), (55.01, 37.01))
    assert r.seconds == 123.4 and r.meters == 987 and r.points[0] == [55.0, 37.0]
    router._get = lambda path: (_ for _ in ()).throw(AssertionError("Cache miss"))
    assert router.route((55, 37), (55.01, 37.01)).seconds == 123.4
    router.close()


def test_initial_refusal_counts_do_not_include_busy(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(speed_m_s=3), agents, cfg)
    env.run()
    m = refusal_metrics(env)
    expected = sum(
        r["attempt"] == 0
        and r["eligible"]
        and r["reason"] == "policy_skip"
        and r["initial_logistics_affordable"]
        and r["initial_full_feasible"]
        and r["travel_s"] <= cfg.max_delivery_s
        for r in env.logs["decisions"]
    )
    assert m["primary_affordable_policy_skips"] == expected


def test_known_configuration_bypasses_edl_and_beta_actor(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(), agents, cfg)
    a = agents[0]
    c = env.couriers[0]
    o = sample_order(data, np.random.default_rng(1), cfg, "k", 0)
    cost = evaluate_cost(c, o, env.router, cfg)
    first = a.decide_price(c, o, cost, 0, env.public)
    a.osr[first.key] = {"n": 100, "mean": first.context.copy()}
    a.cfr.counts[first.key] = 100

    def forbidden(*args, **kwargs):
        raise AssertionError("Known route invoked adaptive EDL/actor")

    a.model.forward = forbidden
    assert a.decide_price(c, o, cost, 0, env.public).branch == "CFR"


def test_precommit_prices_do_not_depend_on_current_roster(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(), agents, cfg)
    captured = {}
    original = env.agents[0].decide_price

    def inspect(*args, **kwargs):
        d = original(*args, **kwargs)
        captured["decision"] = d
        assert not env.logs["tenders"]
        return d

    env.agents[0].decide_price = inspect
    o = sample_order(data, np.random.default_rng(1), cfg, "precommit", 0)
    env.tender_batch([o])
    assert captured["decision"].rng_state["bit_generator"] == "PCG64"
    assert all(
        "features" in r and "log_probability" in r for r in env.logs["decisions"]
    )


def test_tie_shadow_label_and_signed_cost_component(setup_market):
    cfg, _, data, agents = setup_market
    env = Market(data, FixtureRouter(), agents, cfg)
    o = sample_order(data, np.random.default_rng(1), cfg, "tie", 0)
    c = env.couriers[0]
    cost = evaluate_cost(c, o, env.router, cfg)
    bid = (cost.lower + o.U) / 2
    assert env.cf_utility(
        o, bid, cost, [{"bid": bid, "travel_s": cost.travel_s}]
    ) == pytest.approx((bid - cost.lower) / 2)
    other = evaluate_cost(
        c, o, env.router, replace(cfg, fatigue_per_second=0.01, desired_shift_s=3600)
    )
    assert other.fatigue == -36 and other.lower == pytest.approx(
        max(0, cost.lower - 36)
    )


def test_original_assets_required_and_checkpoint_fingerprint(setup_market, tmp_path):
    from brmarl.experiment import fingerprint, load_checkpoint

    cfg, ac, data, agents = setup_market
    with pytest.raises(FileNotFoundError):
        load_assets(tmp_path / "missing.pkl")
    saved = {
        "schema": 2,
        "agents": agents,
        "data_fingerprint": fingerprint(data),
        "torch_rng": torch.get_rng_state(),
    }
    torch.save(saved, tmp_path / "cp.pt")
    changed = copy.deepcopy(data)
    changed["source"] = "another_map"
    with pytest.raises(ValueError, match="mismatch"):
        load_checkpoint(tmp_path / "cp.pt", changed)
