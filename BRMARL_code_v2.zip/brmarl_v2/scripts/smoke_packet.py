from pathlib import Path
import sys, json

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from brmarl.config import MarketConfig, AgentConfig, ParallelConfig
from brmarl.data import make_fixture_assets, prepare_route_cache
from brmarl.experiment import train, test

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    assets = make_fixture_assets(root / "data/fixture.json")
    cfg = MarketConfig(
        B=1800,
        n_couriers=10,
        target_new_orders=8,
        cap_new_orders=8,
        expected_original_polygons=None,
        expected_order_points=None,
    )
    spec = prepare_route_cache(
        assets, root / "outputs/smoke/routes", fixture=True, config=cfg
    )
    ac = AgentConfig(model_adv_weight=0.0, context_epochs=1)
    par = ParallelConfig(workers=4, markets_per_batch=12, device="cpu", progress=False)
    agents, summary = train(
        assets,
        cfg,
        ac,
        n_batches=2,
        parallel_cfg=par,
        route_spec=spec,
        fixture=True,
        output=root / "outputs/smoke/train",
    )
    print(
        "SUMMARY",
        len(summary),
        "markets",
        summary["shift"].nunique(),
        "completed",
        int(summary.completed.sum()),
        flush=True,
    )
    envs, result = test(
        assets,
        root / "outputs/smoke/train/checkpoint.pt",
        n_shifts=1,
        output=root / "outputs/smoke/test",
        adaptive=True,
        route_spec=spec,
        fixture=True,
        shap_enabled=True,
        progress=False,
    )
    print("TEST", int(result.completed.sum()), flush=True)
