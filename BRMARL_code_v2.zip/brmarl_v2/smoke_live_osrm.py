"""Optional v2 integration check: synthetic points, true OSRM cache misses.

Not an experiment on MPID_pl. Requires network access; no synthetic-time fallback.
"""

from pathlib import Path
import json
import torch
from brmarl.config import MarketConfig, AgentConfig
from brmarl.data import make_fixture_assets, prepare_route_cache
from brmarl.cache import SecondsRouter
from brmarl.agent import BRMARLAgent
from brmarl.environment import Market
from brmarl.evaluation import report

if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    out = root / "outputs/live_osrm_v2"
    out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    assets = make_fixture_assets(root / "data/fixture.json")
    cfg = MarketConfig(
        B=3600,
        n_couriers=10,
        target_new_orders=8,
        cap_new_orders=8,
        expected_original_polygons=None,
        expected_order_points=None,
        break_probability_enabled=False,
    )
    spec = prepare_route_cache(assets, out / "routes", fixture=False, config=cfg)
    agents = [BRMARLAgent(i, AgentConfig(), cfg) for i in range(10)]
    router = SecondsRouter(spec)
    try:
        env = Market(assets, router, agents, cfg, training=False)
        summary = env.run()
        metrics = report(env, out, False)
        print(
            json.dumps(
                {
                    "scope": "synthetic geography, actual OSRM seconds, no physical movement interpolation",
                    "completed": int(summary.completed.sum()),
                    "routing": router.stats(),
                    **metrics,
                },
                indent=2,
            )
        )
    finally:
        router.close()
