"""Execute both notebooks cell by cell without requiring kernel TCP sockets.

This runner is useful in restricted containers. A fresh IPython namespace is
created for each notebook; the test notebook obtains agents from its checkpoint.
"""

import argparse
import os
from pathlib import Path

import nbformat
import matplotlib
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output
from matplotlib_inline.backend_inline import configure_inline_support


def execute(path):
    nb = nbformat.read(path, as_version=4)
    InteractiveShell.clear_instance()
    shell = InteractiveShell.instance()
    matplotlib.use("module://matplotlib_inline.backend_inline")
    configure_inline_support(shell, "inline")
    counter = 0
    try:
        for cell in nb.cells:
            if cell.cell_type != "code":
                continue
            counter += 1
            print(f"{path.name}: cell {counter}", flush=True)
            with capture_output() as captured:
                result = shell.run_cell(cell.source, store_history=False)
            cell.execution_count = counter
            cell.outputs = []
            for name, value in (
                ("stdout", captured.stdout),
                ("stderr", captured.stderr),
            ):
                if value:
                    cell.outputs.append(
                        nbformat.v4.new_output("stream", name=name, text=value)
                    )
                    print(value, end="", flush=True)
            for output in captured.outputs:
                cell.outputs.append(
                    nbformat.v4.new_output(
                        "display_data", data=output.data, metadata=output.metadata
                    )
                )
            error = result.error_before_exec or result.error_in_exec
            if error:
                cell.outputs.append(
                    nbformat.v4.new_output(
                        "error",
                        ename=type(error).__name__,
                        evalue=str(error),
                        traceback=[],
                    )
                )
                raise error
    finally:
        nb.metadata["execution_verification"] = {
            "runner": "IPython in-process, fresh namespace per notebook",
            "mode": os.environ.get("BRMARL_MODE", "original"),
        }
        nbformat.write(nb, path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("fixture", "original"), default="fixture")
    parser.add_argument("--train-batches", type=int, default=1)
    parser.add_argument("--test-shifts", type=int, default=2)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    os.chdir(root)
    os.environ.update(
        BRMARL_MODE=args.mode,
        BRMARL_TRAIN_BATCHES=str(args.train_batches),
        BRMARL_TEST_SHIFTS=str(args.test_shifts),
    )
    for filename in ("01_train_brmarl.ipynb", "02_test_brmarl.ipynb"):
        execute(root / filename)
