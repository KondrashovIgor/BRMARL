"""Only the parent renders: fixed console rows or persistent Jupyter widgets."""

import sys


class MarketProgress:
    def __init__(self, shift_ids, B, enabled=True):
        self.bars = {}
        self.B = B
        self.enabled = enabled
        if not enabled:
            return
        try:
            from IPython import get_ipython

            notebook = (
                get_ipython() is not None and "IPKernelApp" in get_ipython().config
            )
        except Exception:
            notebook = False
        if notebook:
            from tqdm.notebook import tqdm
        else:
            from tqdm import tqdm
        for pos, sid in enumerate(shift_ids):
            self.bars[sid] = tqdm(
                total=B / 3600,
                desc=f"Market {sid:04}",
                position=pos,
                leave=True,
                unit="model h",
                dynamic_ncols=True,
                mininterval=0.3,
                disable=not notebook and not sys.stderr.isatty(),
            )

    def reset(self, shift_ids):
        if not self.bars:
            return
        old = list(self.bars.values())
        self.bars = {}
        for bar, sid in zip(old, shift_ids):
            bar.reset(total=self.B / 3600)
            bar.set_description(f"Market {sid:04}")
            self.bars[sid] = bar

    def write(self, message):
        if self.bars:
            from tqdm import tqdm

            tqdm.write(message)
        else:
            print(message, flush=True)

    def update(self, sid, now, phase="simulate", **postfix):
        bar = self.bars.get(sid)
        if bar is None:
            return
        value = min(self.B, max(0, now)) / 3600
        bar.update(max(0, value - bar.n))
        bar.set_postfix(phase=phase, **postfix, refresh=False)

    def close(self):
        for bar in self.bars.values():
            bar.close()
