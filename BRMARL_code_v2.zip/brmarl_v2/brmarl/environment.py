"""Discrete-event market. Commitments, breaks and returns are physical events."""

from dataclasses import dataclass, field, asdict
from collections import defaultdict
from pathlib import Path
import heapq, json, math, copy, time
from .telemetry import Timings, timed_method
import numpy as np
import pandas as pd
from .sampling import (
    ArrivalProcess,
    sample_order,
    reprice,
    break_probability,
    break_duration,
)
from .costs import evaluate_cost, client_score
from .routing import Route, RoutingError, position_along, offset_point, haversine


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, deque_type)):
        return [clean(x) for x in value]
    if isinstance(value, np.ndarray):
        return clean(value.tolist())
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


deque_type = type(__import__("collections").deque())


@dataclass
class Courier:
    id: int
    home: tuple
    position: tuple
    rng: object
    shadow_rng: object = None
    rest_rng: object = None
    status: str = "idle"
    busy_until: float = 0.0
    completed: int = 0
    work_s: float = 0.0
    continuous_work_s: float = 0.0
    continuous_since: float = 0.0
    money: float = 0.0
    shaped: float = 0.0
    return_cost: float = 0.0
    break_cost: float = 0.0
    segments: list = field(default_factory=list)
    pending: object = None

    def available(self, now, B):
        return self.status == "idle" and now < B

    def locate(self, now):
        self.continuous_work_s = (
            max(0.0, now - self.continuous_since) if self.status != "break" else 0.0
        )
        # Position stays at the last completed stop throughout a commitment.
        # It is a departure anchor for hypothetical skipped-commitment shadows,
        # not an assertion about the courier's physical road position.


class Market:
    def __init__(self, assets, router, agents, cfg, shift_id=0, training=True):
        if not cfg.full_offer_feedback:
            raise NotImplementedError(
                "This prototype requires full post-auction offer feedback; censored-feedback training needs a separate learner."
            )
        self.assets = assets
        self.router = router
        self.agents = agents
        self.cfg = cfg
        self.shift = shift_id
        self.training = training
        self.timings = Timings()
        self.progress_callback = None
        self.rng = np.random.default_rng(cfg.seed + 100003 * shift_id)
        self.couriers = []
        # Household points stay fixed across shifts; market and policy draws use separate streams.
        homes = np.random.default_rng(cfg.seed).choice(
            len(assets["home_points"]),
            cfg.n_couriers,
            replace=len(assets["home_points"]) < cfg.n_couriers,
        )
        for i, j in enumerate(homes):
            home = tuple(assets["home_points"][int(j)])
            self.couriers.append(
                Courier(
                    i,
                    home,
                    home,
                    np.random.default_rng(cfg.seed + 1009 * i + 100003 * shift_id),
                    np.random.default_rng(
                        cfg.seed + 900001 + 1009 * i + 100003 * shift_id
                    ),
                    np.random.default_rng(
                        cfg.seed + 800001 + 1009 * i + 100003 * shift_id
                    ),
                )
            )
        self.public = {
            c.id: {
                "position": c.home,
                "time_s": 0.0,
                "wins": 0,
                "last_bid_ratio": 0.5,
                "busy_until": 0.0,
            }
            for c in self.couriers
        }
        self.events = []
        self.counter = 0
        self.now = 0.0
        self.round = 0
        self.next_order = 0
        self.logs = {
            k: []
            for k in [
                "tenders",
                "decisions",
                "awards",
                "ledger",
                "movements",
                "positions",
                "rounds",
                "choice_updates",
            ]
        }
        self.samples = []
        self.order_ids = set()
        self.arrivals = ArrivalProcess(cfg)
        for t, n in self.arrivals.schedule(self.rng):
            self.push(t, 1, "new", n)
        self.push(cfg.B, 2, "shift_end", None)
        for a in agents:
            a.begin_shift()

    def push(self, time_s, priority, kind, payload):
        self.counter += 1
        heapq.heappush(
            self.events, (float(time_s), priority, self.counter, kind, payload)
        )

    def log(self, table, **kw):
        self.logs[table].append({"shift": self.shift, **kw})

    def movement(self, c, route, start, status, order_id=None):
        end = start + route.seconds
        self.log(
            "movements",
            courier=c.id,
            kind=status,
            order_id=order_id,
            start_s=start,
            end_s=end,
            duration_s=route.seconds,
            distance_m=route.meters,
            geometry=route.points,
            geometry_kind=(
                "endpoint_schematic"
                if self.router.source in ("DIRECTED_SECONDS_CACHE", "SYNTHETIC_ROUTER")
                else "road_geometry"
            ),
            routing_source=route.source,
        )
        return (start, end, route)

    def run(self):
        simulation_start = time.perf_counter()
        while self.events:
            time_s = self.events[0][0]
            self.now = time_s
            for c in self.couriers:
                c.locate(time_s)
            jobs = []
            while self.events and abs(self.events[0][0] - time_s) < 1e-7:
                _, _, _, kind, payload = heapq.heappop(self.events)
                if kind == "complete":
                    self.complete(self.couriers[payload])
                elif kind == "break_end":
                    c = self.couriers[payload]
                    if c.segments:
                        c.position = tuple(c.segments[-1][2].points[-1])
                    c.locate(time_s)
                    c.status = "idle"
                    c.segments = []
                    c.continuous_since = time_s
                    c.continuous_work_s = 0.0
                    if time_s >= self.cfg.B:
                        self.return_home(c)
                elif kind == "home_end":
                    c = self.couriers[payload]
                    c.position = c.home
                    c.status = "home"
                    c.segments = []
                elif kind == "new":
                    for _ in range(payload):
                        o = sample_order(
                            self.assets,
                            self.rng,
                            self.cfg,
                            f"{self.shift}:{self.next_order}",
                            time_s,
                        )
                        self.next_order += 1
                        self.order_ids.add(o.order_id)
                        jobs.append(o)
                elif kind == "retry":
                    jobs.append(payload)
                elif kind == "shift_end":
                    for c in self.couriers:
                        if c.status == "idle":
                            self.return_home(c)
            if time_s < self.cfg.B:
                for lo in range(0, len(jobs), self.cfg.batch_max):
                    self.tender_batch(jobs[lo : lo + self.cfg.batch_max])
            for c in self.couriers:
                c.locate(time_s)
                self.log(
                    "positions",
                    time_s=time_s,
                    courier=c.id,
                    lat=c.position[0],
                    lon=c.position[1],
                    status=c.status,
                    busy_until=c.busy_until,
                )
            if self.progress_callback:
                self.progress_callback(self.now, "simulate", len(self.logs["tenders"]))
        self.timings.add("simulation_wall", time.perf_counter() - simulation_start)
        finalize_start = time.perf_counter()
        if self.progress_callback:
            self.progress_callback(self.cfg.B, "finalize", len(self.logs["tenders"]))
        if self.training:
            # Factual continuation signal gives skip decisions credit for later returns.
            # Alternatives remain one-step model-based comparisons, explicitly labelled.
            for a in self.agents:
                records = a.choice_history
                future = 0.0
                for rec in reversed(records):
                    chosen = rec["chosen"]
                    reward = rec["actual_reward"]
                    future = reward + 0.98 * future
                    vals = np.asarray(rec["values"], float)
                    vals += 0.98 * rec.get("continuation_estimate", 0.0)
                    vals[chosen] = future
                    rec["values"] = vals
                    self.log(
                        "choice_updates",
                        courier=a.id,
                        key=rec["key"],
                        chosen=chosen,
                        label_kind="factual_return_to_go_and_model_based_alternatives",
                        values=vals.tolist(),
                    )
                a.end_shift(True)
        self.timings.add("finalize_wall", time.perf_counter() - finalize_start)
        return self.summary()

    @timed_method("costs_inclusive")
    def prepare_costs(self, jobs):
        delivery_legs = {}
        for j, o in enumerate(jobs):
            try:
                delivery_legs[j] = self.router.route(o.centroid, o.client, False)
            except RoutingError as exc:
                delivery_legs[j] = None
                self.log(
                    "rounds",
                    round=self.round,
                    time_s=self.now,
                    event="delivery_leg_error",
                    order_id=o.order_id,
                    message=str(exc),
                )
        result = {}
        for c in self.couriers:
            for j, o in enumerate(jobs):
                try:
                    if delivery_legs[j] is None:
                        raise RoutingError("Delivery leg unavailable")
                    result[c.id, j] = evaluate_cost(
                        c, o, self.router, self.cfg, delivery_legs[j]
                    )
                except RoutingError as exc:
                    result[c.id, j] = None
                    self.log(
                        "rounds",
                        round=self.round,
                        time_s=self.now,
                        event="route_error",
                        courier=c.id,
                        order_id=o.order_id,
                        message=str(exc),
                    )
        return result

    @timed_method("tender_inclusive")
    def tender_batch(self, jobs):
        self.round += 1
        costs = self.prepare_costs(jobs)
        decisions = {}
        selected = {}
        policies = {}
        keys = {}
        actual = defaultdict(list)
        # All shadow proposals are generated before actual participation is resolved.
        for c, a in zip(self.couriers, self.agents):
            viable = []
            ds = []
            cs = []
            os = []
            for j, o in enumerate(jobs):
                cost = costs[c.id, j]
                if cost is None:
                    continue
                d = a.decide_price(
                    c,
                    o,
                    cost,
                    self.now,
                    self.public,
                    shadow=not c.available(self.now, self.cfg.B),
                )
                decisions[c.id, j] = d
                if c.available(self.now, self.cfg.B) and self.is_feasible(cost, o):
                    viable.append(j)
                    ds.append(d)
                    cs.append(cost)
                    os.append(o)
            if viable:
                ix, key, policy = a.choose(ds, cs, os, c, self.now)
                chosen = viable[ix] if ix >= 0 else -1
                selected[c.id] = chosen
                policies[c.id] = policy
                keys[c.id] = (key, viable)
                if chosen >= 0:
                    d = decisions[c.id, chosen]
                    a.commit(d)
                    actual[chosen].append(
                        {
                            "courier": c.id,
                            "bid": d.bid,
                            "travel_s": costs[c.id, chosen].travel_s,
                        }
                    )
            else:
                selected[c.id] = -1
        award_ids = {}
        all_cf = {}
        actual_rewards = defaultdict(float)
        for j, o in enumerate(jobs):
            offers = actual[j]
            winner = None
            top = []
            if offers:
                scores = [
                    client_score(o, b["bid"], b["travel_s"], self.cfg) for b in offers
                ]
                best = max(scores)
                top = [b for b, s in zip(offers, scores) if abs(s - best) <= 1e-8]
                winner = top[int(self.rng.integers(len(top)))]["courier"]
                award_ids[j] = winner
            reason_counts = defaultdict(int)
            for c, a in zip(self.couriers, self.agents):
                cost = costs[c.id, j]
                d = decisions.get((c.id, j))
                eligible = c.available(self.now, self.cfg.B)
                if cost is None:
                    reason = "routing_error"
                elif not eligible:
                    reason = "busy" if c.status == "working" else c.status
                elif cost.travel_s > self.cfg.max_delivery_s:
                    reason = "delivery_deadline"
                elif cost.lower > o.U:
                    reason = "price_infeasible"
                elif (
                    self.cfg.finish_before_shift_end
                    and self.now + cost.execution_s > self.cfg.B
                ):
                    reason = "shift_deadline"
                elif selected[c.id] != j:
                    reason = "selected_other" if selected[c.id] >= 0 else "policy_skip"
                else:
                    reason = "submitted"
                reason_counts[reason] += 1
                reward = (d.bid - cost.lower) if winner == c.id else 0.0
                if winner == c.id:
                    actual_rewards[c.id] = reward
                shadow_reward = None
                critical_ratio = None
                critical_id = None
                grid_rewards = None
                ranking = []
                if d is not None:
                    other = [b for b in offers if b["courier"] != c.id]
                    shadow_reward = self.cf_utility(o, d.bid, cost, other)
                    grid = d.lower + np.linspace(0, 1, a.cfg.price_grid) * (
                        d.U - d.lower
                    )
                    grid_rewards = [
                        self.cf_utility(o, float(p), cost, other) for p in grid
                    ]
                    if other:
                        ratio = a.preference.ratio(o.pid)

                        def critical(b):
                            return b["bid"] + ratio * (b["travel_s"] - cost.travel_s)

                        bc = min(other, key=critical)
                        critical_id = bc["courier"]
                        critical_ratio = critical(bc) / max(o.U, 1)
                    else:
                        critical_ratio = float("inf")
                    if offers:
                        win_offer = next(b for b in offers if b["courier"] == winner)
                        ranking = [
                            (o.pid, win_offer, b)
                            for b in offers
                            if b["courier"] != winner
                        ]
                    # Busy shadows are diagnostic only: they are not feasible counterfactual choices.
                    if (
                        eligible
                        and self.is_feasible(cost, o)
                        and self.cfg.full_offer_feedback
                    ):
                        if selected[c.id] == j:
                            a.observe(
                                d,
                                reward,
                                critical_ratio,
                                ranking,
                                grid_rewards,
                                self.training,
                                critical_id,
                            )
                        elif self.training:
                            # Unchosen one-step information trains the threshold bank, not an on-policy actor.
                            a.threshold_events.append(
                                (d.key, critical_ratio, d.x, critical_id)
                            )
                            a.bank.observe(d.key, critical_ratio, d.x, critical_id)
                            a.endshift.append(
                                (
                                    d,
                                    (
                                        min(
                                            a.cfg.modes - 1,
                                            max(
                                                0,
                                                int(
                                                    np.clip(critical_ratio, 0, 0.999999)
                                                    * a.cfg.modes
                                                ),
                                            ),
                                        )
                                        if np.isfinite(critical_ratio)
                                        else a.cfg.modes - 1
                                    ),
                                    np.asarray(grid_rewards),
                                )
                            )
                    all_cf[c.id, j] = shadow_reward
                row = {
                    "round": self.round,
                    "time_s": self.now,
                    "order_id": o.order_id,
                    "pid": o.pid,
                    "attempt": o.attempt,
                    "courier": c.id,
                    "status_before": c.status,
                    "eligible": eligible,
                    "selected": selected[c.id] == j,
                    "reason": reason,
                    "U": o.U,
                    "initial_U": o.initial_U,
                    "winner": winner,
                    "won": winner == c.id,
                    "logistics_cost": cost.logistics if cost else None,
                    "fee": cost.fee if cost else None,
                    "lower": cost.lower if cost else None,
                    "travel_s": cost.travel_s if cost else None,
                    "execution_s": cost.execution_s if cost else None,
                    "estimated_execution_s": o.service_s,
                    "home_cost": cost.home_cost if cost else None,
                    "expected_home_cost": cost.expected_home if cost else None,
                    "fatigue": cost.fatigue if cost else None,
                    "bid": d.bid if selected[c.id] == j and d else None,
                    "shadow_bid": d.bid if d else None,
                    "branch": d.branch if d else None,
                    "reward": reward,
                    "shadow_utility": shadow_reward,
                    "shadow_label": (
                        "verified_one_step"
                        if eligible and cost and self.is_feasible(cost, o)
                        else "ineligible_hypothetical"
                    ),
                    "initial_logistics_affordable": bool(
                        cost and cost.logistics < o.initial_U
                    ),
                    "initial_full_feasible": bool(
                        cost
                        and cost.lower <= o.initial_U
                        and cost.travel_s <= self.cfg.max_delivery_s
                    ),
                    "origin_lat": c.position[0],
                    "origin_lon": c.position[1],
                    "information_phase": "pre_participation",
                    "shadow_origin": "last_completed_or_drift_point",
                    "position_semantics": "departure_anchor_not_road_position",
                    "routing_source": self.router.source,
                }
                if d:
                    row.update(
                        {
                            "alpha": d.alpha,
                            "beta": d.beta,
                            "atom_prob": d.atom_prob,
                            "al": d.aspiration,
                            "mcd": d.mcd,
                            "osr_distance": d.osr_distance,
                            "rho": d.rho.tolist(),
                            "spatial_weights": d.spatial_weights.tolist(),
                            "encoder_version": d.encoder_version,
                            "actor_version": d.actor_version,
                            "log_probability": d.log_probability,
                            "atom_action": d.atom,
                            "normalized_action": d.xi,
                            "features": d.x.tolist(),
                            "context": d.context.tolist(),
                            "latent_before": d.previous.tolist(),
                            "memory": d.memory.tolist(),
                            "policy_rng_before": d.rng_state,
                        }
                    )
                    self.samples.append(
                        {
                            "courier": c.id,
                            "decision": d,
                            "row_index": len(self.logs["decisions"]),
                        }
                    )
                self.log("decisions", **row)
            self.log(
                "tenders",
                round=self.round,
                time_s=self.now,
                order_id=o.order_id,
                pid=o.pid,
                attempt=o.attempt,
                created_s=o.created_s,
                U=o.U,
                initial_U=o.initial_U,
                centroid=list(o.centroid),
                client=list(o.client),
                winner=winner,
                n_responses=len(offers),
                n_tied=len(top),
                offers=offers,
                reasons=dict(reason_counts),
                oracle_alpha=o.theta[0],
                oracle_beta=o.theta[1],
                oracle_gamma=o.theta[2],
                routing_source=self.router.source,
            )
            if winner is None:
                if (
                    self.cfg.allow_repricing
                    and o.attempt + 1 < self.cfg.max_attempts
                    and self.now + self.cfg.retry_delay_s < self.cfg.B
                ):
                    old = o.U
                    o.U = reprice(o.U, self.rng, self.cfg.retry_cap_U)
                    o.attempt += 1
                    o.history.append([self.now, old, o.U])
                    self.push(self.now + self.cfg.retry_delay_s, 1, "retry", o)
            # Commit only after every candidate/label has used the same pre-round courier state.
        for c, a in zip(self.couriers, self.agents):
            if c.id not in keys:
                continue
            key, viable = keys[c.id]
            chosen_j = selected[c.id]
            chosen = 0 if chosen_j < 0 else viable.index(chosen_j) + 1
            vals = np.zeros(self.cfg.batch_max + 1)
            for k, j in enumerate(viable):
                cost = costs[c.id, j]
                # Simple explicit continuation: opportunity time at baseline wage, no copied future trace.
                vals[k + 1] = (
                    all_cf.get((c.id, j), 0.0)
                    - 0.05 * cost.execution_s * self.cfg.market_hour_price / 3600
                )
            if self.training:
                a.choice_history.append(
                    {
                        "key": key,
                        "policy": policies[c.id].copy(),
                        "values": vals,
                        "chosen": chosen,
                        "actual_reward": actual_rewards[c.id],
                        "continuation_estimate": 0.0,
                    }
                )
        for j, winner in award_ids.items():
            self.award(
                self.couriers[winner],
                jobs[j],
                costs[winner, j],
                decisions[winner, j].bid,
            )
        # Frozen weights do not imply a frozen recurrent state. A courier also
        # observes tenders it skips or shadows while busy. Pool parallel items
        # so their arbitrary enumeration does not choose the next GRU state.
        for c, a in zip(self.couriers, self.agents):
            if selected[c.id] >= 0:
                continue  # selected context was committed above
            observed = [
                decisions[c.id, j] for j in range(len(jobs)) if (c.id, j) in decisions
            ]
            if observed:
                a.h = np.mean([d.context for d in observed], axis=0).astype(np.float32)
                a.latent = np.mean([d.hidden for d in observed], axis=0).astype(
                    np.float32
                )

    def is_feasible(self, cost, order):
        return bool(
            cost.travel_s <= self.cfg.max_delivery_s
            and cost.lower <= order.U
            and (
                not self.cfg.finish_before_shift_end
                or self.now + cost.execution_s <= self.cfg.B
            )
        )

    def cf_utility(self, order, bid, cost, others):
        if not self.is_feasible(cost, order):
            return 0.0
        score = client_score(order, bid, cost.travel_s, self.cfg)
        scores = [
            client_score(order, b["bid"], b["travel_s"], self.cfg) for b in others
        ]
        if scores and score < max(scores) - 1e-8:
            return 0.0
        ties = sum(abs(s - score) <= 1e-8 for s in scores)
        return float((bid - cost.lower) / (ties + 1))

    def award(self, c, order, cost, bid):
        if not c.available(self.now, self.cfg.B):
            raise AssertionError("Cannot award an unavailable courier")
        r1 = self.router.route(c.position, order.centroid, True)
        r2 = self.router.route(order.centroid, order.client, True)
        # Route and table must agree in source units; geometry requests may differ negligibly.
        c.status = "working"
        c.busy_until = self.now + cost.execution_s
        c.pending = (order, cost, bid)
        c.segments = [
            self.movement(c, r1, self.now, "to_centroid", order.order_id),
            self.movement(c, r2, self.now + r1.seconds, "to_client", order.order_id),
        ]
        if cost.execution_s > r1.seconds + r2.seconds:
            rest = Route(
                cost.execution_s - r1.seconds - r2.seconds,
                0.0,
                [list(order.client), list(order.client)],
                self.router.source,
            )
            c.segments.append(
                self.movement(
                    c,
                    rest,
                    self.now + r1.seconds + r2.seconds,
                    "service",
                    order.order_id,
                )
            )
        self.push(c.busy_until, 0, "complete", c.id)
        c.shaped += bid - cost.lower
        self.public[c.id].update(
            {"busy_until": c.busy_until, "last_bid_ratio": bid / max(order.U, 1)}
        )
        self.log(
            "awards",
            round=self.round,
            order_id=order.order_id,
            attempt=order.attempt,
            courier=c.id,
            start_s=self.now,
            finish_s=c.busy_until,
            bid=bid,
            logistics_cost=cost.logistics,
            fee=cost.fee,
            monetary_profit=bid - cost.logistics - cost.fee,
            shaped_reward=bid - cost.lower,
            execution_s=cost.execution_s,
            travel_s=cost.travel_s,
            home_cost_estimate=cost.expected_home,
        )

    def complete(self, c):
        if c.status != "working" or c.pending is None:
            raise AssertionError("Completion without commitment")
        order, cost, bid = c.pending
        c.position = order.client
        c.status = "idle"
        c.pending = None
        c.segments = []
        c.completed += 1
        c.work_s += cost.execution_s
        c.money += bid - cost.logistics - cost.fee
        self.public[c.id].update(
            {
                "position": c.position,
                "time_s": self.now,
                "wins": c.completed,
                "busy_until": self.now,
            }
        )
        self.log(
            "ledger",
            time_s=self.now,
            courier=c.id,
            event="delivery_completed",
            order_id=order.order_id,
            revenue=bid,
            route_cost=cost.logistics,
            fee=cost.fee,
            net=bid - cost.logistics - cost.fee,
        )
        if self.now >= self.cfg.B:
            self.return_home(c)
            return
        c.continuous_work_s = self.now - c.continuous_since
        if (
            self.cfg.break_probability_enabled
            and c.rest_rng.random() < break_probability(c.continuous_work_s, self.cfg)
        ):
            self.take_break(c)

    @timed_method("drift_inclusive")
    def take_break(self, c):
        duration = break_duration(c.rest_rng, self.cfg)
        route = None
        target = c.position
        for _ in range(20):
            p = offset_point(c.position, self.cfg.break_radius_m, c.rest_rng)
            try:
                p = self.router.nearest(p)
                if haversine(c.position, p) > self.cfg.break_radius_m:
                    continue
                candidate = self.router.route(c.position, p, True)
                if candidate.seconds <= duration:
                    target = p
                    route = candidate
                    break
            except RoutingError:
                continue
        if route is None:
            route = Route(
                0.0, 0.0, [list(c.position), list(c.position)], self.router.source
            )
        c.status = "break"
        c.busy_until = self.now + duration
        c.segments = [self.movement(c, route, self.now, "break_move")]
        c.break_cost += route.seconds * self.cfg.market_hour_price / 3600
        self.log(
            "ledger",
            time_s=self.now,
            courier=c.id,
            event="break_reposition",
            duration_s=duration,
            target=list(target),
            route_cost=route.seconds * self.cfg.market_hour_price / 3600,
            net=-route.seconds * self.cfg.market_hour_price / 3600,
        )
        self.push(c.busy_until, 0, "break_end", c.id)

    def return_home(self, c):
        if c.status in ("home", "returning", "working", "break"):
            return
        route = self.router.route(c.position, c.home, True)
        c.status = "returning"
        c.busy_until = self.now + route.seconds
        c.return_cost = (
            route.seconds * self.cfg.market_hour_price / 3600 * self.cfg.home_weight
        )
        c.segments = [self.movement(c, route, self.now, "return_home")]
        self.log(
            "ledger",
            time_s=self.now,
            courier=c.id,
            event="return_home",
            route_cost=c.return_cost,
            net=-c.return_cost,
        )
        self.push(c.busy_until, 0, "home_end", c.id)

    def summary(self):
        result = []
        for c in self.couriers:
            net = c.money - c.return_cost - c.break_cost
            fatigue = self.cfg.fatigue_per_second * (
                c.work_s - self.cfg.desired_shift_s
            )
            result.append(
                {
                    "shift": self.shift,
                    "courier": c.id,
                    "completed": c.completed,
                    "work_s": c.work_s,
                    "delivery_profit": c.money,
                    "return_cost": c.return_cost,
                    "break_cost": c.break_cost,
                    "net_profit": net,
                    "shift_utility": net - self.cfg.satisfying_income - fatigue,
                    "shaped_reward_sum": c.shaped,
                    "end_s": c.busy_until,
                    "overtime_s": max(0, c.busy_until - self.cfg.B),
                    "final_status": c.status,
                }
            )
        return pd.DataFrame(result)

    def save(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        for name, rows in self.logs.items():
            with (directory / f"{name}.jsonl").open("w", encoding="utf-8") as f:
                for row in rows:
                    f.write(
                        json.dumps(clean(row), ensure_ascii=False, allow_nan=False)
                        + "\n"
                    )
            flat = []
            for row in rows:
                flat.append(
                    {
                        k: (
                            json.dumps(clean(v), ensure_ascii=False)
                            if isinstance(v, (dict, list, tuple, np.ndarray))
                            else clean(v)
                        )
                        for k, v in row.items()
                    }
                )
            pd.DataFrame(flat).to_csv(directory / f"{name}.csv", index=False)
        self.summary().to_csv(directory / "couriers.csv", index=False)
        self.timings.save(directory / "timings.json")
        if hasattr(self.router, "stats"):
            (directory / "routing_stats.json").write_text(
                json.dumps(self.router.stats(), indent=2)
            )
        (directory / "manifest.json").write_text(
            json.dumps(
                clean(
                    {
                        "market": self.cfg.to_dict(),
                        "data_source": self.assets["source"],
                        "routing_source": self.router.source,
                        "new_orders": len(self.order_ids),
                        "attempts": len(self.logs["tenders"]),
                        "training_or_adaptive": self.training,
                        "arrival_location_min": self.arrivals.location_min,
                        "arrival_target_interval_min": self.arrivals.target_interval_min,
                    }
                ),
                indent=2,
            )
        )
