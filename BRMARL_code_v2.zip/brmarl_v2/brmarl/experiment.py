"""Full-shift packet training and separate prequential online evaluation."""

from pathlib import Path
from dataclasses import asdict, replace
import copy, hashlib, json, time
import pandas as pd
import torch
from .config import MarketConfig, AgentConfig, ParallelConfig
from .agent import BRMARLAgent
from .environment import Market
from .routing import FixtureRouter
from .cache import SecondsRouter
from .data import prepare_route_cache, merge_route_deltas
from .parallel import rollout_packet, merge_packet
from .inference import resolve_device
from .learning import place_agent
from .evaluation import report
from .progress import MarketProgress


def fingerprint(assets):
    return hashlib.sha256(json.dumps(assets, sort_keys=True).encode()).hexdigest()


def make_router(cfg, root, fixture=False, route_spec=None):
    if route_spec:
        return SecondsRouter(route_spec)
    if fixture:
        return FixtureRouter()
    raise ValueError(
        "Original mode requires prepare_route_cache; no silent OSRM-only path"
    )


def _save(agents, cfg, ac, par, assets, output, n_batches, n_markets, spec):
    clean = copy.deepcopy(agents)
    for a in clean:
        place_agent(a, "cpu")
        a.inference_backend = None
        for key in (
            "buffer",
            "endshift",
            "choice_history",
            "threshold_events",
            "preference_events",
            "reward_events",
        ):
            setattr(a, key, [])
        a.history = a.history[-2048:]
    state = {
        "schema": 2,
        "agents": clean,
        "market": asdict(cfg),
        "agent": asdict(ac),
        "parallel": asdict(par),
        "data_fingerprint": fingerprint(assets),
        "data_source": assets["source"],
        "n_training_batches": n_batches,
        "n_training_shifts": n_markets,
        "route_spec": str(spec),
        "torch_rng": torch.get_rng_state(),
        "cuda_rng": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
        "algorithm": "Synchronous full-shift packets; independent courier policies shared across market replicas",
    }
    tmp = output / "checkpoint.partial"
    torch.save(state, tmp)
    tmp.replace(output / "checkpoint.pt")
    (output / "run.json").write_text(
        json.dumps(
            {
                k: v
                for k, v in state.items()
                if k not in ("agents", "torch_rng", "cuda_rng")
            },
            indent=2,
        )
    )


def train(
    assets,
    market_cfg=None,
    agent_cfg=None,
    n_batches=20,
    output="outputs/train",
    fixture=False,
    parallel_cfg=None,
    route_spec=None,
    resume=None,
):
    cfg = market_cfg or MarketConfig()
    ac = agent_cfg or AgentConfig(model_adv_weight=0.0)
    par = parallel_cfg or ParallelConfig()
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if n_batches < 1:
        raise ValueError("n_batches must be positive")
    torch.set_num_threads(1)
    torch.manual_seed(ac.seed)
    device = resolve_device(par.device)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(ac.seed)
    start_batch = 0
    start_market = 0
    if resume:
        saved = load_checkpoint(resume, assets)
        cfg = MarketConfig(**saved["market"])
        ac = AgentConfig(**saved["agent"])
        agents = saved["agents"]
        start_batch = saved["n_training_batches"]
        start_market = saved["n_training_shifts"]
    else:
        agents = [BRMARLAgent(i, ac, cfg) for i in range(cfg.n_couriers)]
    if route_spec is None:
        if not fixture:
            raise ValueError(
                "Prepare route_spec from existing memmap BEFORE workers start"
            )
        route_spec = prepare_route_cache(
            assets, output / "route_cache", fixture=True, config=cfg
        )
    route_spec = str(Path(route_spec).resolve())
    print(
        f"Training: {par.workers} CPU workers / {par.markets_per_batch} markets / device={device}",
        flush=True,
    )
    for a in agents:
        place_agent(a, device)
        a.train_chunk = par.train_chunk
    summaries = (
        pd.read_csv(output / "training_summary.csv").to_dict("records")
        if resume and (output / "training_summary.csv").exists()
        else []
    )
    timings = (
        json.loads((output / "batch_timings.json").read_text())
        if resume and (output / "batch_timings.json").exists()
        else []
    )
    delta_row = 0
    dashboard = MarketProgress(
        range(start_market, start_market + par.markets_per_batch), cfg.B, par.progress
    )
    try:
        for batch in range(start_batch, start_batch + n_batches):
            offset = start_market + (batch - start_batch) * par.markets_per_batch
            ids = list(range(offset, offset + par.markets_per_batch))
            directory = output / f"batch_{batch:04}"
            completed, rows, stats = rollout_packet(
                assets, agents, cfg, par, route_spec, ids, directory, dashboard
            )
            dashboard.write(
                f"Batch {batch}: all {len(completed)} markets finished; learning starts"
            )
            for sid in ids:
                dashboard.update(sid, cfg.B, "learning")
            t = time.perf_counter()
            merge_packet(agents, completed)
            stats["merge_wall_s"] = time.perf_counter() - t
            t = time.perf_counter()
            updates = [a.end_shift(True) for a in agents]
            if device.type == "cuda":
                torch.cuda.synchronize(device)
            stats["learning_wall_s"] = time.perf_counter() - t
            stats["agent_updates"] = updates
            t = time.perf_counter()
            delta_row = merge_route_deltas(route_spec, delta_row)
            stats["cache_merge_wall_s"] = time.perf_counter() - t
            for row in rows:
                row["batch"] = batch
            summaries.extend(rows)
            stats.update(
                batch=batch,
                markets=len(completed),
                last_market=max(ids),
                policy_version=agents[0].version,
            )
            pd.DataFrame(rows).to_csv(directory / "summary.csv", index=False)
            t = time.perf_counter()
            _save(
                agents,
                cfg,
                ac,
                par,
                assets,
                output,
                batch + 1,
                offset + par.markets_per_batch,
                route_spec,
            )
            stats["checkpoint_wall_s"] = time.perf_counter() - t
            timings.append(stats)
            (directory / "batch_timing.json").write_text(json.dumps(stats, indent=2))
            pd.DataFrame(summaries).to_csv(output / "training_summary.csv", index=False)
            (output / "batch_timings.json").write_text(json.dumps(timings, indent=2))
            dashboard.write(
                f"Batch {batch}: rollout/barrier={stats['rollout_barrier_wall_s']:.1f}s, learning={stats['learning_wall_s']:.1f}s, mean neural batch={stats['mean_agent_batch']:.1f}"
            )
    finally:
        dashboard.close()
    return agents, pd.DataFrame(summaries)


def load_checkpoint(path, assets=None):
    saved = torch.load(path, map_location="cpu", weights_only=False)
    if saved.get("schema") != 2:
        raise ValueError(
            "v1 checkpoint needs explicit migration; retrain the v2 packet protocol"
        )
    if assets is not None and saved["data_fingerprint"] != fingerprint(assets):
        raise ValueError("Checkpoint/map mismatch")
    torch.set_rng_state(saved["torch_rng"])
    if torch.cuda.is_available() and saved.get("cuda_rng"):
        torch.cuda.set_rng_state_all(saved["cuda_rng"])
    return saved


def test(
    assets,
    checkpoint,
    n_shifts=2,
    output="outputs/test",
    adaptive=False,
    fixture=False,
    shap_enabled=True,
    market_override=None,
    route_spec=None,
    device="cpu",
    progress=True,
    maps_enabled=True,
):
    saved = load_checkpoint(checkpoint, assets)
    cfg = MarketConfig(**saved["market"])
    if market_override:
        cfg = replace(cfg, **market_override)
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    agents = saved["agents"]
    device = resolve_device(device)
    for a in agents:
        place_agent(a, device)
        a.defer_updates = False
        a.inference_backend = None
    spec = route_spec or saved["route_spec"]
    summaries = []
    envs = []
    shifts = [saved["n_training_shifts"] + 1000 + k for k in range(n_shifts)]
    bars = MarketProgress(shifts, cfg.B, progress)
    try:
        for k, sid in enumerate(shifts):
            router = make_router(cfg, output, fixture, spec)
            try:
                env = Market(assets, router, agents, cfg, sid, adaptive)
                env.progress_callback = (
                    lambda now, phase, attempts, sid=sid: bars.update(
                        sid, now, phase, attempts=attempts
                    )
                )
                summary = env.run()
                report(
                    env,
                    output / f"shift_{k:03}",
                    shap_enabled and k == n_shifts - 1,
                    maps_enabled,
                )
                summaries.append(summary)
                envs.append(env)
                bars.update(sid, cfg.B, "done")
            finally:
                router.close()
        result = pd.concat(summaries, ignore_index=True)
        result.to_csv(output / "test_summary.csv", index=False)
        return envs, result
    finally:
        bars.close()


def paired_repricing_control(
    assets, checkpoint, output, fixture=False, route_spec=None
):
    result = {}
    for enabled in (False, True):
        envs, summary = test(
            assets,
            checkpoint,
            1,
            Path(output) / str(enabled),
            adaptive=False,
            fixture=fixture,
            route_spec=route_spec,
            shap_enabled=False,
            market_override={"allow_repricing": enabled},
        )
        result[str(enabled)] = {
            "net": float(summary.net_profit.sum()),
            "completed": int(summary.completed.sum()),
        }
    Path(output, "comparison.json").write_text(json.dumps(result, indent=2))
    return result
