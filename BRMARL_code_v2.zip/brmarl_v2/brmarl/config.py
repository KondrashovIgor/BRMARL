from dataclasses import dataclass, asdict

MARKET_HOUR_PRICE = 500.0
B = 43200.0


@dataclass
class MarketConfig:
    seed: int = 42
    B: float = B
    n_couriers: int = 10
    market_hour_price: float = MARKET_HOUR_PRICE
    max_delivery_s: float = 4800.0
    service_min_s: float = 1200.0
    service_max_s: float = 1800.0
    service_is_additional: bool = (
        False  # estimates are metadata; actual busy time is OSRM travel only
    )
    target_new_orders: int = 300
    cap_new_orders: int = 300
    batch_min: int = 1
    batch_max: int = 3
    arrival_scale_min: float = 1.0
    initial_U_min: float = 400.0
    initial_U_max: float = 1800.0
    retry_cap_U: float = 1800.0
    retry_delay_s: float = 120.0
    max_attempts: int = 20
    allow_repricing: bool = True
    break_probability_enabled: bool = True
    break_hazard_scale_s: float = 1.0
    break_min_s: float = 600.0
    break_max_s: float = 1200.0
    break_mean_s: float = 900.0
    break_std_s: float = 300.0
    break_radius_m: float = 2000.0
    platform_fee: float = 0.0
    home_weight: float = 1.0
    fatigue_per_second: float = 0.0
    desired_shift_s: float = B
    satisfying_income: float = 0.0
    stop_mean_wins: float = 12.0
    stop_scale_wins: float = 3.0
    finish_before_shift_end: bool = False
    full_offer_feedback: bool = True
    profile: str = "driving"
    osrm_url: str = "https://router.project-osrm.org"
    osrm_timeout_s: float = 25.0
    osrm_min_interval_s: float = 0.15
    expected_original_polygons: int | None = 385
    expected_order_points: int | None = 20160
    score_normalized: bool = False

    def __post_init__(self):
        if self.B <= 0 or self.n_couriers < 1:
            raise ValueError("Invalid shift/population")
        if not 1 <= self.batch_min <= self.batch_max:
            raise ValueError("Invalid batch bounds")
        if self.target_new_orders <= 0:
            raise ValueError("target_new_orders must be positive")
        if self.retry_delay_s <= 0 or self.max_attempts < 1:
            raise ValueError("Retries must advance time")
        if self.break_hazard_scale_s <= 0 or self.arrival_scale_min <= 0:
            raise ValueError("Invalid sigmoid scale")
        if not 0 <= self.service_min_s <= self.service_max_s:
            raise ValueError("Invalid service interval")

    def to_dict(self):
        return asdict(self)


@dataclass
class AgentConfig:
    seed: int = 42
    hidden: int = 24
    modes: int = 6
    actor_lr: float = 0.0007
    model_lr: float = 0.001
    context_lr: float = 0.001
    update_every: int = 16
    min_known: int = 6
    osr_distance: float = 0.65
    mcd_variance: float = 0.003
    dropout: float = 0.15
    mcd_passes: int = 5
    al_lr: float = 0.08
    al_prior_max: float = 0.35
    entropy_weight: float = 0.01
    model_adv_weight: float = 0.1
    price_grid: int = 21
    memory_window: int = 128
    cfr_min_count: int = 6
    context_epochs: int = 2
    spatial_weighting: bool = True
    use_al: bool = True
    use_edl: bool = True
    use_memory: bool = True


@dataclass
class ParallelConfig:
    workers: int = 4
    markets_per_batch: int = 12
    device: str = "auto"
    inference_wait_ms: float = 4.0
    max_inference_batch: int = 256
    train_chunk: int = 256
    progress: bool = True
    rpc_timeout_s: float = 300.0
    worker_timeout_s: float = 3600.0
    report_maps: bool = False

    def __post_init__(self):
        if self.workers < 1 or self.markets_per_batch < 1 or self.train_chunk < 1:
            raise ValueError("Invalid parallel configuration")
