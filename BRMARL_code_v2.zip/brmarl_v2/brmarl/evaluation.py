from pathlib import Path
import json, copy
import numpy as np
import pandas as pd
from .models import FEATURES


def refusal_metrics(env):
    df = pd.DataFrame(env.logs["decisions"])
    td = pd.DataFrame(env.logs["tenders"])
    if df.empty:
        return {"new_orders": len(env.order_ids), "attempts": 0}
    first = df["attempt"].eq(0)
    affordable = df["initial_logistics_affordable"].fillna(False)
    available = df["eligible"].fillna(False)
    time_ok = df["travel_s"].le(env.cfg.max_delivery_s)
    discretionary = df["reason"].eq("policy_skip")
    metric = {
        "new_orders": len(env.order_ids),
        "attempts": len(td),
        "primary_attempts": int(td["attempt"].eq(0).sum()),
        "retries": int(td["attempt"].gt(0).sum()),
        "awarded": int(td["winner"].notna().sum()),
        "no_responses": int(td["n_responses"].eq(0).sum()),
        "primary_affordable_policy_skips": int(
            (
                first
                & affordable
                & available
                & time_ok
                & discretionary
                & df["initial_full_feasible"]
            ).sum()
        ),
        "primary_affordable_selected_other": int(
            (
                first
                & affordable
                & available
                & time_ok
                & df["reason"].eq("selected_other")
            ).sum()
        ),
        "primary_affordable_price_infeasible": int(
            (first & affordable & available & df["reason"].eq("price_infeasible")).sum()
        ),
        "primary_affordable_unavailable": int((first & affordable & ~available).sum()),
        "actor_updates": sum(a.learning_steps for a in env.agents),
        "CFR_decisions": int(df["branch"].eq("CFR").sum()),
        "BRMARL_decisions": int(df["branch"].eq("BRMARL").sum()),
    }
    active = first & available & time_ok & df["initial_full_feasible"].fillna(False)
    offered = df.loc[active].groupby("order_id")["selected"].any()
    failed = set(td.loc[td["attempt"].eq(0) & td["n_responses"].eq(0), "order_id"])
    metric["primary_no_response_with_full_feasible_courier"] = sum(
        not x and k in failed for k, x in offered.items()
    )
    metric["interpretation"] = (
        "Descriptive refusal indicators; not proof of tacit collusion. Busy/break/other-choice are separated."
    )
    return metric


def validate_market(env):
    """Scientific invariants over actual commitment intervals, not labels alone."""
    awards = pd.DataFrame(env.logs["awards"])
    dec = pd.DataFrame(env.logs["decisions"])
    if not awards.empty:
        assert not awards["order_id"].duplicated().any(), "An order was awarded twice"
        for cid, g in awards.groupby("courier"):
            g = g.sort_values("start_s")
            assert np.all(
                g["start_s"].to_numpy()[1:] >= g["finish_s"].to_numpy()[:-1] - 1e-7
            ), "Overlapping commitments"
            assert np.allclose(g["finish_s"] - g["start_s"], g["execution_s"])
            for _, r in g.iterrows():
                if not dec.empty:
                    inside = dec[
                        (dec.courier == cid)
                        & (dec.time_s > r.start_s + 1e-7)
                        & (dec.time_s < r.finish_s - 1e-7)
                    ]
                    assert not inside[
                        "selected"
                    ].any(), "Real bid during committed execution"
    if not dec.empty:
        assert not dec.loc[
            ~dec["eligible"], "selected"
        ].any(), "Unavailable real participation"
        assert not dec.loc[dec["reason"].eq("price_infeasible"), "selected"].any()
        real = dec[dec["selected"]]
        assert (real["bid"] <= real["U"] + 1e-6).all()
        assert (real["bid"] >= real["lower"] - 1e-6).all()
        assert real.groupby(["round", "courier"]).size().le(1).all()
    assert len(env.order_ids) <= env.cfg.cap_new_orders
    assert all(c.status == "home" for c in env.couriers)
    summary = env.summary()
    assert np.allclose(
        summary.net_profit,
        summary.delivery_profit - summary.return_cost - summary.break_cost,
    )
    return {
        "status": "passed",
        "invariants": [
            "single_award",
            "non_overlapping_execution",
            "no_busy_real_bids",
            "one_real_bid_per_batch",
            "price_bounds",
            "order_cap",
            "return_home",
            "financial_ledger",
        ],
    }


def save_map(env, path):
    import folium

    center = np.mean(np.asarray(env.assets["home_points"]), axis=0).tolist()
    m = folium.Map(location=center, zoom_start=12, tiles="OpenStreetMap")
    colors = [
        "blue",
        "red",
        "green",
        "purple",
        "orange",
        "darkred",
        "cadetblue",
        "darkblue",
        "darkgreen",
        "black",
    ]
    groups = {
        c.id: folium.FeatureGroup(name=f"Courier {c.id}").add_to(m)
        for c in env.couriers
    }
    for c in env.couriers:
        folium.Marker(
            c.home,
            tooltip=f"Home {c.id}",
            icon=folium.Icon(color=colors[c.id % len(colors)]),
        ).add_to(groups[c.id])
    for r in env.logs["movements"]:
        if len(r["geometry"]) < 2:
            continue
        folium.PolyLine(
            r["geometry"],
            color=colors[r["courier"] % len(colors)],
            weight=2,
            dash_array="5,5" if r["kind"] in ("break_move", "return_home") else None,
            tooltip=f"{r['kind']} {r['start_s']:.0f}–{r['end_s']:.0f}s; {r['order_id']}",
        ).add_to(groups[r["courier"]])
    folium.LayerControl().add_to(m)
    m.save(str(path))
    geo = {"type": "FeatureCollection", "features": []}
    for r in env.logs["movements"]:
        geo["features"].append(
            {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[p[1], p[0]] for p in r["geometry"]],
                },
                "properties": {k: v for k, v in r.items() if k != "geometry"},
            }
        )
    from .environment import clean

    Path(path).with_suffix(".geojson").write_text(
        json.dumps(clean(geo), allow_nan=False)
    )


def explain_prices(
    env, directory, max_rows=6, background_rows=12, nsamples=96, courier_id=0
):
    """Kernel SHAP of the actual end-of-shift BRMARL pricing head, not a surrogate."""
    import shap

    directory = Path(directory)
    eligible = [
        s for s in env.samples if env.logs["decisions"][s["row_index"]]["eligible"]
    ]
    actual = [s for s in eligible if s["decision"].branch == "BRMARL"]
    if actual:
        if not any(s["courier"] == courier_id for s in actual):
            courier_id = actual[0]["courier"]
        samples = [s for s in actual if s["courier"] == courier_id]
        selection = "eligible_BRMARL_decisions"
    else:
        if not eligible:
            return {"status": "no_eligible_samples"}
        if not any(s["courier"] == courier_id for s in eligible):
            courier_id = eligible[0]["courier"]
        samples = [s for s in eligible if s["courier"] == courier_id]
        selection = "counterfactual_BRMARL_head_probe_on_CFR_contexts"
    background = np.stack([s["decision"].x for s in samples[:background_rows]])
    rows = []
    checks = []
    for sample in samples[-max_rows:]:
        d = sample["decision"]
        fn = env.agents[courier_id].explanation_model(d.context, d.previous, d.memory)
        explainer = shap.KernelExplainer(fn, background, feature_names=FEATURES)
        values = np.asarray(
            explainer.shap_values(d.x[None], nsamples=nsamples, l1_reg=0, silent=True)
        ).reshape(-1)
        base = float(np.asarray(explainer.expected_value).reshape(-1)[0])
        pred = float(fn(d.x[None])[0])
        residual = abs(base + values.sum() - pred)
        checks.append(residual)
        for name, value, phi in zip(FEATURES, d.x, values):
            rows.append(
                {
                    "courier": courier_id,
                    "decision_row": sample["row_index"],
                    "feature": name,
                    "value": float(value),
                    "shap": float(phi),
                    "base": base,
                    "prediction": pred,
                    "additivity_error": residual,
                }
            )
    df = pd.DataFrame(rows)
    df.to_csv(directory / "shap_price.csv", index=False)
    imp = (
        df.assign(abs_shap=df.shap.abs())
        .groupby("feature")
        .abs_shap.mean()
        .sort_values(ascending=False)
    )
    imp.to_csv(directory / "shap_global_importance.csv")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 5))
    imp.sort_values().plot.barh(ax=ax)
    ax.set_xlabel("Mean |SHAP|, normalized price")
    fig.tight_layout()
    fig.savefig(directory / "shap_importance.png", dpi=140)
    plt.close(fig)
    result = {
        "status": "computed",
        "courier": courier_id,
        "explained_rows": len(samples[-max_rows:]),
        "max_additivity_error": max(checks),
        "target": "end_of_shift_BRMARL_expected_bid_ratio_at_fixed_historical_context_and_memory",
        "selection": selection,
        "scope": "Pricing head only, not CFR gate, participation policy, causal effects or historical parameter snapshot.",
    }
    (directory / "shap_manifest.json").write_text(json.dumps(result, indent=2))
    return result


def report(env, directory, shap_enabled=False, maps_enabled=True):
    directory = Path(directory)
    env.save(directory)
    check = validate_market(env)
    metrics = refusal_metrics(env)
    (directory / "checks.json").write_text(json.dumps(check, indent=2))
    (directory / "metrics.json").write_text(json.dumps(metrics, indent=2))
    if maps_enabled:
        save_map(env, directory / "trajectory_map.html")
    if shap_enabled:
        status = explain_prices(env, directory)
        (directory / "shap_status.json").write_text(json.dumps(status, indent=2))
    return metrics
