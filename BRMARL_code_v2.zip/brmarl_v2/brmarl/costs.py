from dataclasses import dataclass
from scipy.special import expit
import numpy as np


@dataclass
class Cost:
    travel_s: float
    service_s: float
    execution_s: float
    route_m: float
    logistics: float
    fee: float
    home_s: float
    home_cost: float
    stop_hazard: float
    expected_home: float
    fatigue: float
    lower: float


def stop_hazard(next_win, mean, scale):
    # Stable logistic discrete hazard: pmf / survivor(n-1).
    a = (next_win - mean) / scale
    b = (next_win - 1 - mean) / scale
    return float(np.clip(expit(a) * (-np.expm1(-1 / scale)), 0, 1))


def evaluate_cost(courier, order, router, cfg, delivery_leg=None):
    leg1 = router.route(courier.position, order.centroid, False)
    leg2 = (
        delivery_leg
        if delivery_leg is not None
        else router.route(order.centroid, order.client, False)
    )
    home = router.route(order.client, courier.home, False)
    travel = leg1.seconds + leg2.seconds
    execution = travel + order.service_s if cfg.service_is_additional else travel
    logistics = travel * cfg.market_hour_price / 3600
    home_cost = home.seconds * cfg.market_hour_price / 3600
    hazard = stop_hazard(courier.completed + 1, cfg.stop_mean_wins, cfg.stop_scale_wins)
    fatigue = cfg.fatigue_per_second * (courier.work_s - cfg.desired_shift_s)
    lower = (
        logistics + cfg.platform_fee + cfg.home_weight * hazard * home_cost + fatigue
    )
    return Cost(
        travel,
        order.service_s,
        execution,
        leg1.meters + leg2.meters,
        logistics,
        cfg.platform_fee,
        home.seconds,
        home_cost,
        hazard,
        cfg.home_weight * hazard * home_cost,
        fatigue,
        max(0.0, lower),
    )


def client_score(order, bid, travel_s, cfg):
    alpha, beta, gamma = order.theta
    dp = order.U - bid
    dt = cfg.max_delivery_s - travel_s
    if cfg.score_normalized:
        dp /= max(order.U, 1)
        dt /= cfg.max_delivery_s
    # All agents have the same zero compute-time component in this prototype.
    return float(alpha * dp + beta * dt)
