from collections import deque
from dataclasses import dataclass
import copy, math, time
import numpy as np
from scipy.stats import beta as beta_dist
import torch
from torch import nn
from torch.nn import functional as F
from .models import (
    D,
    FEATURES,
    ContextModel,
    PricingModel,
    ThresholdBank,
    RegretTable,
    PreferenceBelief,
    context_key,
)
from .routing import haversine


@dataclass
class Decision:
    bid: float
    xi: float
    atom: bool
    branch: str
    key: tuple
    x: np.ndarray
    context: np.ndarray
    previous: np.ndarray
    memory: np.ndarray
    alpha: float
    beta: float
    atom_prob: float
    rho: np.ndarray
    mcd: float
    osr_distance: float
    aspiration: float
    lower: float
    U: float
    hidden: np.ndarray
    price_policy: np.ndarray
    opponent_features: np.ndarray
    opponent_ids: list
    spatial_weights: np.ndarray
    context_previous: np.ndarray
    encoder_version: int
    actor_version: int
    log_probability: float
    rng_state: dict


class BRMARLAgent:
    def __init__(self, agent_id, cfg, market):
        self.id = agent_id
        self.cfg = cfg
        self.market = market
        # Identical initial weights, independent stochastic actions and histories.
        with torch.random.fork_rng():
            torch.manual_seed(cfg.seed)
            self.context = ContextModel(cfg.hidden, cfg.dropout, cfg.modes)
            self.model = PricingModel(cfg.hidden, cfg.modes)
        self.opt = torch.optim.Adam(self.model.parameters(), lr=cfg.actor_lr)
        self.model.edl_enabled = cfg.use_edl
        self.context_opt = torch.optim.Adam(
            self.context.parameters(), lr=cfg.context_lr
        )
        self.bank = ThresholdBank(cfg.modes, cfg.memory_window)
        self.preference = PreferenceBelief()
        self.cfr = RegretTable(cfg.price_grid)
        self.choice_cfr = RegretTable(market.batch_max + 1)
        self.osr = {}
        self.prototype_examples = {}
        self.al = {}
        self.scale = 100.0
        self.h = np.zeros(cfg.hidden, np.float32)
        self.latent = self.h.copy()
        self.buffer = []
        self.history = []
        self.endshift = []
        self.choice_history = []
        self.learning_steps = 0
        self.version = 0
        self.last_public = {}
        self.completed_outcomes = 0
        self.frozen_digest = None
        self.defer_updates = False
        self.reward_events = []
        self.threshold_events = []
        self.preference_events = []

    def begin_shift(self):
        self.h[:] = 0
        self.latent[:] = 0
        self.context.eval()
        self.model.eval()
        self.endshift = []
        self.choice_history = []
        self.reward_events = []
        self.threshold_events = []
        self.preference_events = []

    def features(self, courier, order, cost, now, public, shadow=False):
        key = context_key(order, cost)
        means = self.bank.summary()
        al = self.al.get(key, self.market.market_hour_price * 0.1)
        dists = [
            haversine(v["position"], order.centroid) / 8 / 4800
            for k, v in public.items()
            if k != self.id
        ]
        x = np.array(
            [
                order.U / 1800,
                cost.logistics / max(order.U, 1),
                cost.travel_s / 4800,
                max(0, self.market.B - now) / self.market.B,
                cost.home_cost / max(order.U, 1),
                courier.completed / 20,
                courier.continuous_work_s / self.market.B,
                order.attempt / max(self.market.max_attempts, 1),
                (self.market.n_couriers - 1) / 10,
                np.min(dists) if dists else 1,
                float(means.mean()),
                al / max(order.U, 1) if self.cfg.use_al else 0.0,
                float(shadow),
                order.service_s / 4800,
            ],
            dtype=np.float32,
        )
        opp = []
        for k, v in sorted(public.items()):
            if k == self.id:
                continue
            opp.append(
                [
                    haversine(v["position"], order.centroid) / 8 / 4800,
                    max(0, now - v.get("time_s", 0)) / self.market.B,
                    v.get("wins", 0) / 20,
                    v.get("last_bid_ratio", 0.5),
                    float(v.get("busy_until", 0) > now),
                ]
            )
        return (
            key,
            np.nan_to_num(np.clip(x, -5, 5)),
            np.asarray(opp, np.float32).reshape(-1, 5),
        )

    def decide_price(self, courier, order, cost, now, public, shadow=False):
        rng = (
            courier.shadow_rng
            if shadow and courier.shadow_rng is not None
            else courier.rng
        )
        rng_state = copy.deepcopy(rng.bit_generator.state)
        key, x, opp = self.features(courier, order, cost, now, public, shadow)
        mem = (
            self.bank.summary()
            if self.cfg.use_memory
            else np.full(self.cfg.modes, 0.5, np.float32)
        )
        request = {
            "agent": self.id,
            "x": x,
            "previous": self.h.copy(),
            "opponents": opp,
            "latent": self.latent.copy(),
            "memory": mem,
            "prototype": self.osr.get(key),
            "cfr_count": self.cfr.counts[key],
        }
        if getattr(self, "inference_backend", None) is not None:
            wait_start = time.perf_counter()
            result = self.inference_backend.infer(request)
            self.inference_wait_s = (
                getattr(self, "inference_wait_s", 0.0)
                + time.perf_counter()
                - wait_start
            )
        else:
            from .inference import NeuralBatcher

            result = NeuralBatcher(
                [self], str(next(self.model.parameters()).device)
            ).infer_many([request])[0]
        c = result["context"]
        a = result["alpha"]
        b = result["beta"]
        atom = result["atom"]
        rho = result["rho"]
        h = result["hidden"]
        spatial = result["spatial"]
        variance = result["mcd"]
        distance = result["distance"]
        known = result["known"]
        grid = np.linspace(0, 1, self.cfg.price_grid)
        # Exact Beta bin masses, including boundary bins, avoid endpoint-density
        # bias when alpha or beta is below one. CFR uses the same price grid.
        edges = np.r_[0.0, (grid[:-1] + grid[1:]) / 2, 1.0]
        masses = np.diff(beta_dist.cdf(edges, float(a), float(b)))
        price_policy = (1 - float(atom)) * masses
        price_policy[-1] += float(atom)
        price_policy /= price_policy.sum()
        if known:
            price_policy = self.cfr.average_policy(key)
            idx = int(rng.choice(len(grid), p=price_policy))
            xi = float(grid[idx])
            is_atom = idx == len(grid) - 1
            branch = "CFR"
        else:
            is_atom = bool(rng.random() < float(atom))
            xi = 1.0 if is_atom else float(rng.beta(float(a), float(b)))
            branch = "BRMARL"
        if known:
            log_probability = float(np.log(max(price_policy[idx], 1e-12)))
        elif is_atom:
            log_probability = float(np.log(max(float(atom), 1e-12)))
        else:
            log_probability = float(
                np.log1p(-float(atom))
                + beta_dist.logpdf(np.clip(xi, 1e-5, 1 - 1e-5), float(a), float(b))
            )
        lo = min(max(cost.lower, 0), order.U)
        bid = lo + xi * (order.U - lo)
        ids = [k for k in sorted(public) if k != self.id]
        return Decision(
            bid,
            xi,
            is_atom,
            branch,
            key,
            x,
            c,
            self.latent.copy(),
            mem.copy(),
            float(a),
            float(b),
            float(atom),
            rho,
            variance,
            distance,
            self.al.get(key, 50.0),
            lo,
            order.U,
            h,
            price_policy,
            opp,
            ids,
            spatial,
            self.h.copy(),
            self.version,
            self.learning_steps,
            log_probability,
            rng_state,
        )

    def win_forecast(self, d, prices):
        ratios = np.asarray(prices) / max(d.U, 1)
        if self.cfg.spatial_weighting and len(d.opponent_ids):
            cdf = sum(
                w * (d.rho @ self.bank.distributions(ratios, j))
                for j, w in zip(d.opponent_ids, d.spatial_weights)
            )
        else:
            cdf = d.rho @ self.bank.distributions(ratios)
        if self.cfg.use_al:
            margin = np.maximum(np.asarray(prices) - d.lower, 1e-6)
            # Extended threshold support permits G(U)<1 (unbeatable/inactive competitors).
            al_cdf = np.clip(1 - max(d.aspiration, 0) / margin, 0, 1)
            cdf = (1 - self.cfg.al_prior_max) * cdf + self.cfg.al_prior_max * al_cdf
        return np.clip(1 - cdf, 0, 1)

    def choose(self, decisions, costs, orders, courier, now):
        n = len(decisions)
        values = []
        for d, c, o in zip(decisions, costs, orders):
            prices = np.linspace(d.lower, d.U, self.cfg.price_grid)
            gain = float(
                d.price_policy @ (self.win_forecast(d, prices) * (prices - d.lower))
            )
            opportunity = 0.15 * c.execution_s * self.market.market_hour_price / 3600
            values.append(max(0.01, gain - opportunity))
        # Action 0 = skip, 1..n = one job only. Fixed-size table masks absent jobs.
        key = tuple(
            [n]
            + [int(o.U // 400) for o in orders]
            + [int(c.logistics // 200) for c in costs]
        )
        prior = np.r_[
            max(10, float(np.mean(values)) * 0.25) if values else 1,
            values,
            np.zeros(self.market.batch_max - n),
        ]
        policy = self.choice_cfr.policy(key, prior)
        mask = np.r_[np.ones(n + 1), np.zeros(self.market.batch_max - n)]
        policy *= mask
        policy /= policy.sum()
        action = int(courier.rng.choice(len(policy), p=policy))
        return action - 1, key, policy

    def commit(self, d):
        self.h = d.context.copy()
        self.latent = d.hidden.copy()

    def observe(
        self,
        d,
        reward,
        critical_ratio,
        ranking_pairs,
        grid_rewards,
        training=True,
        critical_id=None,
    ):
        if not training:
            return
        self.reward_events.append((d.key, float(reward)))
        self.preference_events.extend(ranking_pairs)
        for pid, winner, loser in ranking_pairs:
            self.preference.observe(pid, winner, loser)
        self.threshold_events.append((d.key, critical_ratio, d.x, critical_id))
        label = self.bank.observe(d.key, critical_ratio, d.x, critical_id)
        old = self.al.get(d.key, 50.0)
        self.al[d.key] = (1 - self.cfg.al_lr) * old + self.cfg.al_lr * reward
        self.scale = 0.99 * self.scale + 0.01 * abs(reward - old)
        if d.branch == "BRMARL":
            self.buffer.append((d, float(reward), label, critical_id))
        self.endshift.append((d, label, np.asarray(grid_rewards, float)))
        self.history.append(
            {"branch": d.branch, "reward": reward, "al": old, "target_mode": label}
        )
        if not self.defer_updates and len(self.buffer) >= self.cfg.update_every:
            self.update_online()

    def update_online(self):
        from .learning import update_adapter

        return update_adapter(self, getattr(self, "train_chunk", 256))

    def end_shift(self, training=True):
        if not training or self.defer_updates:
            return
        from .learning import finish_agent

        return finish_agent(self, getattr(self, "train_chunk", 256))

    def explanation_model(self, context, previous, memory):
        """Pure deterministic price-ratio head at fixed pre-decision memory/latent state."""
        model = copy.deepcopy(self.model).cpu().eval()

        def fn(X):
            X = np.asarray(X, np.float32)
            n = len(X)
            with torch.no_grad():
                a, b, q, *_ = model(
                    torch.from_numpy(X),
                    torch.tensor(np.tile(context, (n, 1))),
                    torch.tensor(np.tile(previous, (n, 1))),
                    torch.tensor(np.tile(memory, (n, 1))),
                )
                return ((1 - q) * a / (a + b) + q).numpy()

        return fn
