"""Directed seconds: legacy memmap -> centroid maps -> SQLite delta -> OSRM.

Workers open memmaps read-only. Only the parent merges deltas at a batch barrier.
"""

import json, sqlite3, time, os, threading
from pathlib import Path
from collections import defaultdict
import numpy as np
from .routing import Route, RoutingError, OSRMRouter, FixtureRouter, haversine
from .telemetry import Timings


def coord_key(point):
    return ",".join(f"{float(v):.7f}" for v in point)


class SecondsRouter:
    def __init__(self, spec_path, network_lock=None):
        self.spec_path = Path(spec_path)
        self.spec = json.loads(self.spec_path.read_text())
        s = self.spec
        self.source = (
            "SYNTHETIC_ROUTER" if s.get("fixture") else "DIRECTED_SECONDS_CACHE"
        )
        self.status_callback = None
        self.error_path = self.spec_path.with_name(
            f"routing_errors_{os.getpid()}_{threading.get_ident()}.jsonl"
        )
        self.lock = network_lock
        self.timings = Timings()
        self.counts = defaultdict(int)
        self.errors = []
        self.ids = s.get("coordinate_ids", {})
        self.centers = {coord_key(p): i for i, p in enumerate(s["centroids"])}
        self.orders = {}
        for j, p in enumerate(s["orders"]):
            self.orders.setdefault(coord_key(p), j)
        self.forward = np.load(s["forward_path"], mmap_mode="r")
        self.reverse = np.load(s["reverse_path"], mmap_mode="r")
        self.array = None
        self.index = {}
        if s.get("distance_path"):
            self.array = np.memmap(
                s["distance_path"],
                dtype=s["dtype"],
                mode="r",
                offset=s.get("offset", 0),
                shape=tuple(s["shape"]),
            )
            self.index = {
                int(k): tuple(v)
                for k, v in json.loads(Path(s["index_path"]).read_text()).items()
            }
        self.db = sqlite3.connect(s["delta_path"], timeout=60)
        self.db.execute("PRAGMA busy_timeout=60000")
        self.fallback = (
            FixtureRouter()
            if s.get("fixture")
            else OSRMRouter(
                s["osrm_cache_path"],
                s["osrm_url"],
                s["profile"],
                s["timeout"],
                s["min_interval"],
            )
        )

    def _error(self, record):
        record = {"wall_timestamp": time.time(), **record}
        self.errors.append(record)
        with self.error_path.open("a") as f:
            f.write(json.dumps(record) + "\n")

    def _key(self, a, b):
        return coord_key(a) + ">" + coord_key(b)

    def _legacy(self, a, b):
        if self.array is None:
            return None
        ia, ib = self.ids.get(coord_key(a)), self.ids.get(coord_key(b))
        if ia is None or ib is None or int(ia) not in self.index:
            return None
        start, end = self.index[int(ia)]
        subset = self.array[start:end]
        pos = np.searchsorted(subset[:, 1], int(ib))
        if pos < len(subset) and subset[pos, 1] == int(ib):
            value = float(subset[pos, 2])
            if np.isfinite(value) and 0 <= value < self.spec["missing_sentinel"]:
                return value
        return None

    def _matrix(self, a, b):
        ka, kb = coord_key(a), coord_key(b)
        if ka in self.centers and kb in self.orders:
            value = float(self.forward[self.centers[ka], self.orders[kb]])
        elif ka in self.orders and kb in self.centers:
            value = float(self.reverse[self.centers[kb], self.orders[ka]])
        else:
            return None
        return value if np.isfinite(value) and value >= 0 else None

    def _delta(self, key):
        row = self.db.execute(
            "SELECT seconds FROM seconds_delta WHERE k=?", (key,)
        ).fetchone()
        return float(row[0]) if row else None

    def _record(self, a, b, seconds):
        self.db.execute(
            "INSERT OR IGNORE INTO seconds_delta(k,a,b,seconds) VALUES (?,?,?,?)",
            (self._key(a, b), json.dumps(list(a)), json.dumps(list(b)), seconds),
        )
        self.db.commit()

    def route(self, a, b, geometry=True):
        with self.timings.measure("route_lookup"):
            self.counts["lookups"] += 1
            if coord_key(a) == coord_key(b):
                seconds = 0.0
                origin = "same_point"
            else:
                seconds = self._legacy(a, b)
                origin = "legacy_memmap"
                if seconds is None:
                    seconds = self._matrix(a, b)
                    origin = "centroid_memmap"
                if seconds is None:
                    seconds = self._delta(self._key(a, b))
                    origin = "delta_cache"
                if seconds is None:
                    self.counts["cache_misses"] += 1
                    if self.status_callback:
                        self.status_callback("cache/OSRM wait")
                    if self.lock:
                        t = time.perf_counter()
                        self.lock.acquire()
                        self.timings.add("network_lock_wait", time.perf_counter() - t)
                    try:
                        seconds = self._delta(self._key(a, b))
                        origin = "delta_after_wait"
                        if seconds is None:
                            t = time.perf_counter()
                            try:
                                result = self.fallback.route(a, b, False)
                                seconds = result.seconds
                                origin = "fallback"
                                self.counts["fallback_calls"] += 1
                                self._record(a, b, seconds)
                            except RoutingError as exc:
                                self.counts["errors"] += 1
                                if (
                                    "timed out" in str(exc).lower()
                                    or "timeout" in str(exc).lower()
                                ):
                                    self.counts["timeouts"] += 1
                                self._error(
                                    {
                                        "operation": "route",
                                        "from": list(a),
                                        "to": list(b),
                                        "error": str(exc),
                                    }
                                )
                                raise
                            finally:
                                self.timings.add(
                                    "fallback_wall", time.perf_counter() - t
                                )
                    finally:
                        if self.lock:
                            self.lock.release()
            self.counts[origin] += 1
            # Seconds cache does not contain road geometry or meters. Endpoints are schematic.
            return Route(
                float(seconds),
                float("nan"),
                [list(a), list(b)] if geometry else [],
                self.source,
            )

    def prefetch(self, *args):
        pass  # No Cartesian Table request inside simulation.

    def nearest(self, p):
        if self.spec.get("fixture"):
            return tuple(p)
        if self.lock:
            self.lock.acquire()
        try:
            with self.timings.measure("drift_nearest"):
                self.counts["nearest_calls"] += 1
                return self.fallback.nearest(p)
        except RoutingError as exc:
            self._error({"operation": "nearest", "point": list(p), "error": str(exc)})
            self.counts["errors"] += 1
            if "timed out" in str(exc).lower() or "timeout" in str(exc).lower():
                self.counts["timeouts"] += 1
            raise
        finally:
            if self.lock:
                self.lock.release()

    def stats(self):
        return {
            "http_calls": self.fallback.calls,
            "http_cache_hits": self.fallback.hits,
            "counts": dict(self.counts),
            "timings": self.timings.snapshot(),
            "errors": self.errors,
        }

    def close(self):
        self.db.close()
        self.fallback.close()
