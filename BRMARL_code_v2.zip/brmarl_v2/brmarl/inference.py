"""One device owner; vectorized inference across ready markets of each agent."""

import time
from collections import defaultdict
import numpy as np
import torch
from torch.nn import functional as F


def resolve_device(name="auto"):
    if name == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if str(name).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA requested but unavailable; install a CUDA PyTorch build or choose cpu"
        )
    return torch.device(name)


class NeuralBatcher:
    def __init__(self, agents, device="cpu"):
        self.agents = {a.id: a for a in agents}
        self.device = resolve_device(device)
        self.calls = 0
        self.rows = 0
        self.group_sizes = []
        self.wall_s = 0.0
        for a in agents:
            a.context.to(self.device).eval()
            a.model.to(self.device).eval()

    def infer_many(self, requests):
        start = time.perf_counter()
        groups = defaultdict(list)
        results = [None] * len(requests)
        for i, r in enumerate(requests):
            groups[r["agent"]].append((i, r))
        with torch.no_grad():
            for aid, group in groups.items():
                a = self.agents[aid]
                rs = [r for _, r in group]
                n = len(rs)

                def tensor(key):
                    return torch.as_tensor(
                        np.stack([r[key] for r in rs]),
                        device=self.device,
                        dtype=torch.float32,
                    )

                x, prev, opp = tensor("x"), tensor("previous"), tensor("opponents")
                c, _ = a.context(x, prev, opp)
                repeats = c.unsqueeze(0).expand(a.cfg.mcd_passes, -1, -1)
                probs = torch.softmax(
                    a.context.head(F.dropout(repeats, p=a.cfg.dropout, training=True)),
                    -1,
                )
                variance = probs.var(0, unbiased=False).mean(-1).cpu().numpy()
                cn = c.cpu().numpy()
                known = []
                dist = []
                for j, r in enumerate(rs):
                    p = r["prototype"]
                    d = (
                        float(np.linalg.norm(cn[j] - p["mean"]) / np.sqrt(a.cfg.hidden))
                        if p
                        else float("inf")
                    )
                    dist.append(d)
                    known.append(
                        bool(
                            p
                            and p["n"] >= a.cfg.min_known
                            and d <= a.cfg.osr_distance
                            and variance[j] <= a.cfg.mcd_variance
                            and r["cfr_count"] >= a.cfg.cfr_min_count
                        )
                    )
                aa = np.ones(n)
                bb = np.ones(n)
                q = np.zeros(n)
                rho = np.full((n, a.cfg.modes), 1 / a.cfg.modes)
                hidden = cn.copy()
                unknown = np.flatnonzero(~np.asarray(known))
                if len(unknown):
                    ix = torch.as_tensor(unknown, device=self.device)
                    out = a.model(
                        x[ix], c[ix], tensor("latent")[ix], tensor("memory")[ix]
                    )
                    av, bv, qv, _, rv, hv, _ = out
                    aa[unknown] = av.cpu().numpy()
                    bb[unknown] = bv.cpu().numpy()
                    q[unknown] = qv.cpu().numpy()
                    rho[unknown] = rv.cpu().numpy()
                    hidden[unknown] = hv.cpu().numpy()
                spatial = (
                    torch.softmax(a.model.spatial(opp).squeeze(-1), -1).cpu().numpy()
                    if opp.shape[-2]
                    else np.empty((n, 0))
                )
                for j, (i, r) in enumerate(group):
                    results[i] = {
                        "context": cn[j],
                        "alpha": aa[j],
                        "beta": bb[j],
                        "atom": q[j],
                        "rho": rho[j],
                        "hidden": hidden[j],
                        "spatial": spatial[j],
                        "mcd": float(variance[j]),
                        "distance": dist[j],
                        "known": known[j],
                    }
                self.group_sizes.append(n)
        self.calls += 1
        self.rows += len(requests)
        self.wall_s += time.perf_counter() - start
        return results

    def warmup(self, modes=6, batch=12, seed=0):
        devices = [self.device.index or 0] if self.device.type == "cuda" else []
        with torch.random.fork_rng(devices=devices):
            torch.manual_seed(seed)
            requests = []
            for aid, a in self.agents.items():
                for _ in range(batch):
                    requests.append(
                        {
                            "agent": aid,
                            "x": np.zeros(14, np.float32),
                            "previous": np.zeros(a.cfg.hidden, np.float32),
                            "opponents": np.zeros(
                                (a.market.n_couriers - 1, 5), np.float32
                            ),
                            "latent": np.zeros(a.cfg.hidden, np.float32),
                            "memory": np.ones(modes, np.float32) / modes,
                            "prototype": None,
                            "cfr_count": 0,
                        }
                    )
            self.infer_many(requests)
            if self.device.type == "cuda":
                torch.cuda.synchronize(self.device)
        self.calls = 0
        self.rows = 0
        self.group_sizes = []
        self.wall_s = 0.0

    def stats(self):
        return {
            "device": str(self.device),
            "rpc_microbatches": self.calls,
            "observations": self.rows,
            "mean_agent_batch": (
                float(np.mean(self.group_sizes)) if self.group_sizes else 0.0
            ),
            "max_agent_batch": max(self.group_sizes, default=0),
            "inference_wall_s": self.wall_s,
        }
