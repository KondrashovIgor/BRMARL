"""Small trainable components. CFR is finite-action regret matching, not Deep CFR."""

from collections import defaultdict, deque
import copy
import numpy as np
from scipy.stats import beta as beta_dist
import torch
from torch import nn
from torch.nn import functional as F

FEATURES = [
    "budget",
    "route_cost_ratio",
    "travel_fraction",
    "remaining_shift",
    "home_cost_ratio",
    "completed_fraction",
    "continuous_work",
    "attempt_fraction",
    "estimated_competitors",
    "last_opponent_distance",
    "threshold_mean",
    "aspiration_ratio",
    "busy_shadow",
    "estimated_execution",
]
D = len(FEATURES)


def context_key(order, cost):
    return (
        round(order.centroid[0], 2),
        round(order.centroid[1], 2),
        int(order.U // 500),
        int(cost.travel_s // 1200),
    )


def fit_beta(values):
    x = np.clip(np.asarray(values, float), 1e-5, 1 - 1e-5)
    if len(x) < 4:
        return 1.0, 1.0
    if np.var(x) < 1e-6:
        mu = float(np.mean(x))
        return max(0.05, mu * 100), max(0.05, (1 - mu) * 100)
    try:
        a, b, _, _ = beta_dist.fit(x, floc=0, fscale=1)
        return float(np.clip(a, 0.05, 200)), float(np.clip(b, 0.05, 200))
    except (ValueError, RuntimeError):
        return 1.0, 1.0


class ThresholdBank:
    def __init__(self, modes=6, window=128):
        self.modes = modes
        self.values = [deque(maxlen=window) for _ in range(modes)]
        self.params = [(1.0, 1.0) for _ in range(modes)]
        self.counts = np.zeros(modes, int)
        self.contexts = {}
        self.clock = 0
        self.critical = {}
        self.critical_params = {}

    def observe(self, key, y, x, critical_id=None):
        # Transparent empirical prototypes: bins of effective competitive threshold.
        label = (
            min(self.modes - 1, max(0, int(np.clip(y, 0, 0.999999) * self.modes)))
            if np.isfinite(y)
            else self.modes - 1
        )
        self.values[label].append(float(y))
        self.counts[label] += 1
        self.clock += 1
        if self.counts[label] % 8 == 0:
            interior = [v for v in self.values[label] if 0 < v < 1]
            self.params[label] = fit_beta(interior)
        rec = self.contexts.setdefault(
            key, {"n": 0, "mean": np.asarray(x, float).copy(), "y": deque(maxlen=128)}
        )
        rec["n"] += 1
        rec["mean"] += (np.asarray(x) - rec["mean"]) / rec["n"]
        rec["y"].append(float(y))
        if critical_id is not None:
            ik = (int(critical_id), label)
            v = self.critical.setdefault(ik, deque(maxlen=128))
            v.append(float(y))
            if len(v) % 8 == 0:
                self.critical_params[ik] = fit_beta([z for z in v if 0 < z < 1])
        return label

    def distributions(self, grid, critical_id=None):
        grid = np.asarray(grid, float)
        result = []
        for k, (vals, (a, b)) in enumerate(zip(self.values, self.params)):
            ik = (critical_id, k)
            if critical_id is not None and len(self.critical.get(ik, [])) >= 4:
                vals = self.critical[ik]
                a, b = self.critical_params.get(ik, (a, b))
            if not vals:
                result.append(np.clip(grid, 0, 1))
                continue
            v = np.asarray(vals)
            low = np.mean(v <= 0)
            interior = np.mean((v > 0) & (v < 1))
            upper = np.mean(v == 1)
            cdf = (
                low
                + interior * beta_dist.cdf(np.clip(grid, 0, 1), a, b)
                + upper * (grid >= 1)
            )
            result.append(np.clip(cdf, 0, 1))
        return np.asarray(result)

    def summary(self):
        means = []
        for k, v in enumerate(self.values):
            means.append(
                float(np.mean(np.clip(v, 0, 1))) if v else (k + 0.5) / self.modes
            )
        return np.asarray(means, np.float32)


class ContextModel(nn.Module):
    def __init__(self, hidden, dropout, modes):
        super().__init__()
        self.gru = nn.GRUCell(D, hidden)
        self.set_net = nn.Sequential(nn.Linear(5, hidden), nn.Tanh())
        self.mix = nn.Linear(hidden * 3, hidden)
        self.drop = nn.Dropout(dropout)
        self.head = nn.Linear(hidden, modes)

    def forward(self, x, previous, opponents):
        h = self.gru(x, previous)
        if opponents.numel():
            e = self.set_net(opponents)
            pool = torch.cat([e.mean(-2), e.max(-2).values], -1)
        else:
            pool = torch.zeros((*h.shape[:-1], h.shape[-1] * 2), device=x.device)
        c = torch.tanh(self.mix(torch.cat([h, pool], -1)))
        return c, self.head(self.drop(c))


class PricingModel(nn.Module):
    def __init__(self, hidden, modes):
        super().__init__()
        self.x = nn.Linear(D, hidden)
        self.mem = nn.Linear(modes, hidden)
        self.edl_enabled = True
        self.modes = modes
        layer = nn.TransformerEncoderLayer(
            hidden, 4, hidden * 2, dropout=0.0, batch_first=True, norm_first=False
        )
        self.latent = nn.TransformerEncoder(layer, 1, enable_nested_tensor=False)
        self.edl = nn.Sequential(
            nn.Linear(D + hidden, hidden), nn.Tanh(), nn.Linear(hidden, modes)
        )
        self.actor = nn.Linear(hidden, 3)
        self.value = nn.Linear(hidden, 1)
        self.choice = nn.Sequential(
            nn.Linear(D, hidden), nn.Tanh(), nn.Linear(hidden, 1)
        )
        self.skip = nn.Parameter(torch.tensor(-0.3))
        self.spatial = nn.Linear(5, 1)
        with torch.no_grad():
            self.spatial.weight.copy_(torch.tensor([[-3.0, -0.05, 0.0, -2.0, -3.0]]))
            self.spatial.bias.zero_()
        nn.init.zeros_(self.actor.weight)
        nn.init.zeros_(self.actor.bias)

    def forward(self, x, context, previous, mem):
        single = x.ndim == 1
        if single:
            x = x[None]
            context = context[None]
            previous = previous[None]
            mem = mem[None]
        evidence = (
            F.softplus(self.edl(torch.cat([x, context], -1)))
            if self.edl_enabled
            else torch.zeros((len(x), self.modes), device=x.device)
        )
        rho = (evidence + 1) / (evidence + 1).sum(-1, keepdim=True)
        tokens = torch.stack([self.x(x), context, previous, self.mem(mem * rho)], 1)
        h = self.latent(tokens)[:, -1]
        raw = self.actor(h)
        a = F.softplus(raw[:, 0]) + 0.15
        b = F.softplus(raw[:, 1]) + 0.15
        atom = torch.sigmoid(raw[:, 2] - 2.0)
        v = self.value(h).squeeze(-1)
        if single:
            return a[0], b[0], atom[0], v[0], rho[0], h[0], evidence[0]
        return a, b, atom, v, rho, h, evidence


class RegretTable:
    def __init__(self, n_actions):
        self.n = n_actions
        self.regrets = {}
        self.average = {}
        self.counts = defaultdict(int)

    def policy(self, key, prior=None):
        r = self.regrets.get(key, np.zeros(self.n))
        p = np.maximum(r, 0)
        if p.sum() <= 1e-9:
            p = np.ones(self.n) if prior is None else np.maximum(prior, 1e-8)
        return p / p.sum()

    def update(self, key, rewards, played_policy):
        rewards = np.asarray(rewards, float)
        r = self.regrets.setdefault(key, np.zeros(self.n))
        r += rewards - float(np.dot(played_policy, rewards))
        self.average[key] = self.average.get(key, np.zeros(self.n)) + played_policy
        self.counts[key] += 1

    def average_policy(self, key):
        p = self.average.get(key)
        return self.policy(key) if p is None or p.sum() == 0 else p / p.sum()


class PreferenceBelief:
    """Learns a price/time scoring proxy from revealed rankings, never true theta."""

    def __init__(self):
        self.weights = defaultdict(lambda: np.array([0.5, 0.5]))
        self.n = defaultdict(int)

    def observe(self, pid, winner, loser, scale=1800.0):
        x = np.array(
            [
                (loser["bid"] - winner["bid"]) / scale,
                (loser["travel_s"] - winner["travel_s"]) / scale,
            ]
        )
        w = self.weights[pid]
        z = float(np.clip(w @ x, -30, 30))
        w += 0.05 * (1 - 1 / (1 + np.exp(-z))) * x
        w[:] = np.maximum(w, 0.01)
        w[:] /= w.sum()
        self.n[pid] += 1

    def ratio(self, pid):
        w = self.weights[pid]
        return float(w[1] / w[0])

    def __getstate__(self):
        return {"weights": dict(self.weights), "n": dict(self.n)}

    def __setstate__(self, state):
        self.weights = defaultdict(lambda: np.array([0.5, 0.5]), state["weights"])
        self.n = defaultdict(int, state["n"])
