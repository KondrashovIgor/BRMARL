"""Full-batch on-policy adapter update, chunked only for memory; one optimizer step."""

from collections import deque
import numpy as np
import torch
from torch.nn import functional as F


def place_agent(a, device):
    a.context.to(device)
    a.model.to(device)
    for opt in (a.opt, a.context_opt):
        for state in opt.state.values():
            for k, v in state.items():
                if torch.is_tensor(v):
                    state[k] = v.to(device)


def tensors(a, rows):
    device = next(a.model.parameters()).device

    def t(values, dtype=torch.float32):
        return torch.as_tensor(np.asarray(values), dtype=dtype, device=device)

    ds = [r[0] for r in rows]
    return (
        t,
        ds,
        t([d.x for d in ds]),
        t([d.context for d in ds]),
        t([d.previous for d in ds]),
        t([d.memory for d in ds]),
    )


def update_adapter(a, chunk=256):
    rows = a.buffer
    a.buffer = []
    if not rows:
        return {"samples": 0}
    a.model.train()
    a.opt.zero_grad()
    loss_total = 0.0
    max_lp_error = 0.0
    for start in range(0, len(rows), chunk):
        group = rows[start : start + chunk]
        t, ds, x, ctx, prev, mem = tensors(a, group)
        av, bv, q, v, rho, h, evidence = a.model(x, ctx, prev, mem)
        rewards = np.array([r[1] for r in group])
        labels = t([r[2] for r in group], torch.long)
        xi = t([np.clip(d.xi, 1e-5, 1 - 1e-5) for d in ds])
        atom = t([d.atom for d in ds], torch.bool)
        dist = torch.distributions.Beta(av, bv)
        lp = torch.where(
            atom, torch.log(q + 1e-7), torch.log1p(-q + 1e-7) + dist.log_prob(xi)
        )
        # This diagnostic is measured BEFORE the optimizer step; one sample-policy version per packet.
        max_lp_error = max(
            max_lp_error,
            float((lp.detach() - t([d.log_probability for d in ds])).abs().max().cpu()),
        )
        model_adv = np.zeros(len(ds))
        if a.cfg.model_adv_weight:
            for j, d in enumerate(ds):
                grid = np.linspace(d.lower, d.U, a.cfg.price_grid)
                model_adv[j] = float(a.win_forecast(d, [d.bid])[0]) * (
                    d.bid - d.lower
                ) - float(d.price_policy @ (a.win_forecast(d, grid) * (grid - d.lower)))
        adv = t(
            np.clip(
                (
                    rewards
                    - np.array([d.aspiration for d in ds])
                    + a.cfg.model_adv_weight * model_adv
                )
                / max(a.scale, 25),
                -8,
                8,
            )
        )
        entropy = (
            dist.entropy() * (1 - q)
            - q * torch.log(q + 1e-7)
            - (1 - q) * torch.log1p(-q + 1e-7)
        )
        actor = -lp * adv - a.cfg.entropy_weight * entropy
        alpha = evidence + 1
        target = F.one_hot(labels, a.cfg.modes).float()
        adjusted = target + (1 - target) * alpha
        edl = torch.digamma(alpha.sum(-1)) - torch.digamma(
            alpha.gather(-1, labels[:, None]).squeeze(-1)
        )
        edl += min(
            0.1, 0.01 * (a.learning_steps + 1)
        ) * torch.distributions.kl_divergence(
            torch.distributions.Dirichlet(adjusted),
            torch.distributions.Dirichlet(torch.ones_like(adjusted)),
        )
        if ds[0].opponent_features.shape[0]:
            logits = a.model.spatial(t([d.opponent_features for d in ds])).squeeze(-1)
            targets = t(
                [
                    d.opponent_ids.index(row[3]) if row[3] in d.opponent_ids else -100
                    for d, row in zip(ds, group)
                ],
                torch.long,
            )
            edl += F.cross_entropy(logits, targets, ignore_index=-100, reduction="none")
        losses = actor + 0.2 * edl + 0.1 * (v - t(rewards / 500)) ** 2
        (losses.sum() / len(rows)).backward()
        loss_total += float(losses.detach().sum().cpu())
    torch.nn.utils.clip_grad_norm_(a.model.parameters(), 1.0)
    a.opt.step()
    a.model.eval()
    a.learning_steps += 1
    a.last_learning = {
        "samples": len(rows),
        "loss": loss_total / len(rows),
        "max_behavior_logprob_error": max_lp_error,
    }
    return a.last_learning


def finish_agent(a, chunk=256):
    result = update_adapter(a, chunk)
    for d, label, rewards in a.endshift:
        a.cfr.update(d.key, rewards / 500, a.cfr.policy(d.key))
    device = next(a.context.parameters()).device

    def t(values, dtype=torch.float32):
        return torch.as_tensor(np.asarray(values), device=device, dtype=dtype)

    rows = a.endshift
    a.context.train()
    for _ in range(a.cfg.context_epochs):
        if not rows:
            break
        a.context_opt.zero_grad()
        for start in range(0, len(rows), chunk):
            group = rows[start : start + chunk]
            ds = [r[0] for r in group]
            _, logits = a.context(
                t([d.x for d in ds]),
                t([d.context_previous for d in ds]),
                t([d.opponent_features for d in ds]),
            )
            loss = F.cross_entropy(
                logits, t([r[1] for r in group], torch.long), reduction="sum"
            ) / len(rows)
            loss.backward()
        torch.nn.utils.clip_grad_norm_(a.context.parameters(), 1.0)
        a.context_opt.step()
    a.context.eval()
    for d, _, _ in rows:
        a.prototype_examples.setdefault(d.key, deque(maxlen=8)).append(d)
    examples = [
        (key, d) for key, values in a.prototype_examples.items() for d in values
    ]
    grouped = {}
    with torch.no_grad():
        for start in range(0, len(examples), chunk):
            group = examples[start : start + chunk]
            ds = [d for _, d in group]
            emb, _ = a.context(
                t([d.x for d in ds]),
                t([d.context_previous for d in ds]),
                t([d.opponent_features for d in ds]),
            )
            for (key, _), value in zip(group, emb.cpu().numpy()):
                grouped.setdefault(key, []).append(value)
    a.osr = {
        key: {
            "n": a.bank.contexts.get(key, {"n": 0})["n"],
            "mean": np.mean(vals, axis=0),
        }
        for key, vals in grouped.items()
    }
    for rec in a.choice_history:
        a.choice_cfr.update(rec["key"], np.asarray(rec["values"]) / 500, rec["policy"])
    a.version += 1
    return result
