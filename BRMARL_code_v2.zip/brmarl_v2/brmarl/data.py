"""Explicit adapters for the original map. Coordinates are always (lat, lon)."""

import json, pickle, re
from pathlib import Path
import numpy as np


def _load(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(str(path))
    if path.suffix.lower() in {".pkl", ".pickle"}:
        # Only user's own trusted project pickles should be supplied.
        with path.open("rb") as f:
            return pickle.load(f)
    return json.loads(path.read_text(encoding="utf-8"))


def _prefs(value):
    if isinstance(value, dict):
        if "theta" in value:
            return _prefs(value["theta"])
        aliases = [
            ("alpha", "price", "w_price"),
            ("beta", "time", "w_time"),
            ("gamma", "compute", "w_compute"),
        ]
        vals = [next((value[k] for k in keys if k in value), None) for keys in aliases]
        if vals[0] is None or vals[1] is None:
            raise ValueError(
                f"Preference record must contain alpha,beta: {list(value)}"
            )
        vals[2] = 0.0 if vals[2] is None else vals[2]
    else:
        vals = list(value)
        if len(vals) == 2:
            vals += [0.0]
    arr = np.asarray(vals, dtype=float)
    if (
        arr.shape != (3,)
        or not np.isfinite(arr).all()
        or (arr < 0).any()
        or arr[:2].sum() <= 0
    ):
        raise ValueError("Expected nonnegative theta=(alpha,beta,gamma), alpha+beta>0")
    return arr.tolist()


def original_ids(global_map):
    """Metadata wins over suffix guessing: original IDs may themselves end in -1."""
    ids = []
    keys = set(map(str, global_map))
    for raw, rec in global_map.items():
        pid = str(raw)
        if "augmented" in rec:
            original = not bool(rec["augmented"])
        else:
            match = re.search(r"-(?:[1-9])$", pid)
            original = not (match and pid[: match.start()] in keys)
            if pid.startswith("AUG--AUG-"):
                original = False
        if original:
            ids.append(raw)
    return ids


def export_assets(AUG_global_map, preferences_map, destination, MPID_pl=None):
    """Run this in the original notebook after its data variables are initialized."""
    records = []
    for pid in original_ids(AUG_global_map):
        rec = AUG_global_map[pid]
        points = np.asarray(rec["points cloud"], dtype=float)
        if points.ndim != 2 or points.shape[1] != 2 or not len(points):
            raise ValueError(f"{pid}: points cloud must be an N x 2 lat/lon array")
        pv = preferences_map.get(pid, preferences_map.get(str(pid)))
        if pv is None:
            raise KeyError(f"No preferences for original polygon {pid}")
        # Original workflow uses the arithmetic centroid of the point cloud.
        records.append(
            {
                "pid": str(pid),
                "points": points.tolist(),
                "centroid": points.mean(axis=0).tolist(),
                "theta": _prefs(pv),
                "point_ids": [
                    int(v) if isinstance(v, np.integer) else v
                    for v in rec.get("full map", [None] * len(points))
                ],
            }
        )
    homes = []
    if MPID_pl is not None:
        rows = MPID_pl.to_dicts() if hasattr(MPID_pl, "to_dicts") else MPID_pl
        if isinstance(rows, dict):
            rows = [rows]
        for row in rows:
            for group in row.get("Orders", []):
                orders = group if isinstance(group, list) else [group]
                for o in orders:
                    if "Lat" in o and "Long" in o:
                        homes.append([o["Lat"], o["Long"]])
    if not homes:
        homes = [p for r in records for p in r["points"]]
    payload = {
        "schema": 1,
        "coordinate_order": "lat_lon",
        "source": "original_MPID_AUG",
        "polygons": records,
        "home_points": homes,
    }
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    return {
        "path": str(path),
        "polygons": len(records),
        "order_points": sum(len(r["points"]) for r in records),
    }


def load_assets(path, preferences_path=None, orders_path=None, config=None):
    raw = _load(path)
    if not (isinstance(raw, dict) and "polygons" in raw):
        if preferences_path is None:
            raise ValueError("Supply preferences_path for a raw AUG_global_map pickle")
        prefs = _load(preferences_path)
        temp = Path(path).parent / "brmarl_normalized_assets.json"
        export_assets(raw, prefs, temp, _load(orders_path) if orders_path else None)
        raw = _load(temp)
    if raw.get("coordinate_order") != "lat_lon":
        raise ValueError("Explicit lat_lon coordinates required")
    for rec in raw["polygons"]:
        p = np.asarray(rec["points"], float)
        if p.ndim != 2 or p.shape[1] != 2 or not np.isfinite(p).all():
            raise ValueError("Invalid map points")
        if (np.abs(p[:, 0]) > 90).any() or (np.abs(p[:, 1]) > 180).any():
            raise ValueError("Coordinates out of bounds")
        rec["theta"] = _prefs(rec["theta"])
    if config:
        n = len(raw["polygons"])
        k = sum(len(x["points"]) for x in raw["polygons"])
        if (
            config.expected_original_polygons is not None
            and n != config.expected_original_polygons
        ):
            raise ValueError(
                f"Expected {config.expected_original_polygons} original polygons, found {n}"
            )
        if (
            config.expected_order_points is not None
            and k != config.expected_order_points
        ):
            raise ValueError(
                f"Expected {config.expected_order_points} order points, found {k}"
            )
    return raw


def make_fixture_assets(path, seed=7, polygons=6, points_per_polygon=12):
    """SYNTHETIC engineering fixture; never advertised as the original map."""
    rng = np.random.default_rng(seed)
    recs = []
    for k in range(polygons):
        center = np.array([55.75 + 0.006 * (k // 3), 37.60 + 0.012 * (k % 3)])
        pts = center + rng.normal(0, [0.0015, 0.002], size=(points_per_polygon, 2))
        recs.append(
            {
                "pid": f"FIXTURE-{k}",
                "points": pts.tolist(),
                "centroid": pts.mean(0).tolist(),
                "theta": [0.6, 0.25 + 0.05 * (k % 3), 0.15],
            }
        )
    out = {
        "schema": 1,
        "coordinate_order": "lat_lon",
        "source": "SYNTHETIC_ENGINEERING_FIXTURE",
        "polygons": recs,
        "home_points": [p for r in recs for p in r["points"]],
    }
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(out), encoding="utf-8")
    return out


def prepare_route_cache(
    assets,
    destination,
    distance_array=None,
    idx_dict=None,
    coordinate_to_id=None,
    fixture=False,
    config=None,
    missing_sentinel=10**9,
):
    """Create both directed 385 x 20160 float32 caches, initially NaN, before spawn.

    Pass the existing memmap and absolute original-ID index; no copying of the
    legacy array occurs. Unknown centroid pairs are filled on demand or by the
    explicit prewarm_centroid_pool function. Column order retains duplicate points.
    """
    import hashlib, sqlite3
    from .config import MarketConfig
    from .cache import coord_key

    cfg = config or MarketConfig()
    root = Path(destination).resolve()
    root.mkdir(parents=True, exist_ok=True)
    centers = [p["centroid"] for p in assets["polygons"]]
    points = [v for p in assets["polygons"] for v in p["points"]]
    ids = {}
    for polygon in assets["polygons"]:
        for point, rawid in zip(
            polygon["points"], polygon.get("point_ids", [None] * len(polygon["points"]))
        ):
            if rawid is not None:
                try:
                    ids.setdefault(coord_key(point), int(str(rawid).split("-")[-1]))
                except ValueError:
                    raise ValueError(
                        f"Original point ID {rawid!r} is not an integer ID; pass coordinate_to_id explicitly"
                    )
    if coordinate_to_id is not None:
        for point, rawid in coordinate_to_id.items():
            ids[point if isinstance(point, str) else coord_key(point)] = int(rawid)
    layout = hashlib.sha256(
        json.dumps([centers, points], sort_keys=True).encode()
    ).hexdigest()
    manifest = root / "route_spec.json"
    old = json.loads(manifest.read_text()) if manifest.exists() else None
    if old and (
        old["layout_hash"] != layout
        or old["profile"] != cfg.profile
        or old.get("fixture") != fixture
    ):
        raise ValueError("Route cache layout/profile changed; use another destination")
    for name in ("centroid_to_order.npy", "order_to_centroid.npy"):
        path = root / name
        if not path.exists():
            arr = np.lib.format.open_memmap(
                path, mode="w+", dtype=np.float32, shape=(len(centers), len(points))
            )
            arr[:] = np.nan
            arr.flush()
            del arr
        elif np.load(path, mmap_mode="r").shape != (len(centers), len(points)):
            raise ValueError("Invalid centroid map shape")
    s = {
        "schema": 2,
        "layout_hash": layout,
        "units": "seconds",
        "directional": True,
        "centroids": centers,
        "orders": points,
        "coordinate_ids": ids,
        "shape_centroids": [len(centers), len(points)],
        "forward_path": str(root / "centroid_to_order.npy"),
        "reverse_path": str(root / "order_to_centroid.npy"),
        "delta_path": str(root / "seconds_delta.sqlite"),
        "osrm_cache_path": str(root / "osrm_http.sqlite"),
        "osrm_url": cfg.osrm_url,
        "profile": cfg.profile,
        "timeout": cfg.osrm_timeout_s,
        "min_interval": cfg.osrm_min_interval_s,
        "missing_sentinel": missing_sentinel,
        "fixture": fixture,
    }
    if distance_array is not None:
        if not isinstance(distance_array, np.memmap):
            raise TypeError(
                "distance_array must be the existing memmap (not a loaded copy)"
            )
        if distance_array.ndim != 2 or distance_array.shape[1] != 3:
            raise ValueError("Expected from,to,seconds triples")
        if not idx_dict:
            raise ValueError("Supply idx_dict keyed by original from IDs")
        if not ids:
            raise ValueError(
                "No coordinate-to-original-ID mapping; export point_ids or supply coordinate_to_id"
            )
        index_path = root / "legacy_index.json"
        index_path.write_text(
            json.dumps({str(k): [int(v[0]), int(v[1])] for k, v in idx_dict.items()})
        )
        s.update(
            distance_path=str(Path(distance_array.filename).resolve()),
            dtype=distance_array.dtype.str,
            shape=list(distance_array.shape),
            offset=int(distance_array.offset),
            index_path=str(index_path),
        )
    elif old and old.get("distance_path"):
        for k in ("distance_path", "dtype", "shape", "offset", "index_path"):
            s[k] = old[k]
        s["coordinate_ids"].update(old["coordinate_ids"])
    db = sqlite3.connect(s["delta_path"])
    db.execute("PRAGMA journal_mode=WAL")
    db.execute(
        "CREATE TABLE IF NOT EXISTS seconds_delta(k TEXT PRIMARY KEY,a TEXT,b TEXT,seconds REAL NOT NULL)"
    )
    db.commit()
    db.close()
    manifest.write_text(json.dumps(s))
    return str(manifest)


def merge_route_deltas(spec_path, after_rowid=0):
    """Parent only, after all workers close. Merge both maps and append JSONL."""
    import sqlite3
    from .cache import coord_key

    s = json.loads(Path(spec_path).read_text())
    state_path = Path(spec_path).with_name("export_state.json")
    if state_path.exists():
        after_rowid = max(after_rowid, json.loads(state_path.read_text())["last_rowid"])
    db = sqlite3.connect(s["delta_path"])
    rows = db.execute(
        "SELECT rowid,k,a,b,seconds FROM seconds_delta WHERE rowid>? ORDER BY rowid",
        (after_rowid,),
    ).fetchall()
    db.close()
    centers = {coord_key(p): i for i, p in enumerate(s["centroids"])}
    orders = {}
    for j, p in enumerate(s["orders"]):
        orders.setdefault(coord_key(p), []).append(j)
    forward = np.load(s["forward_path"], mmap_mode="r+")
    reverse = np.load(s["reverse_path"], mmap_mode="r+")
    with Path(spec_path).with_name("route_additions.jsonl").open("a") as f:
        for rowid, key, a, b, seconds in rows:
            a = json.loads(a)
            b = json.loads(b)
            ka, kb = coord_key(a), coord_key(b)
            if ka in centers and kb in orders:
                forward[centers[ka], orders[kb]] = seconds
            if ka in orders and kb in centers:
                reverse[centers[kb], orders[ka]] = seconds
            f.write(
                json.dumps({"from": a, "to": b, "seconds": seconds, "rowid": rowid})
                + "\n"
            )
    forward.flush()
    reverse.flush()
    last = max([after_rowid] + [r[0] for r in rows])
    state_path.write_text(json.dumps({"last_rowid": last}))
    return last


def prewarm_centroid_pool(
    spec_path, centroid_indices=None, order_indices=None, reverse=True, progress=True
):
    """Explicit parent-side bulk OSRM Table prewarm. Resumable; never transpose.

    None means the full selected dimension. The default training notebook only
    allocates the maps; set PREWARM_ALL explicitly for full 7.76M-pair expansion.
    """
    from .cache import SecondsRouter
    from tqdm.auto import tqdm

    s = json.loads(Path(spec_path).read_text())
    router = SecondsRouter(spec_path)
    ci = (
        list(range(len(s["centroids"])))
        if centroid_indices is None
        else list(centroid_indices)
    )
    oi = list(range(len(s["orders"]))) if order_indices is None else list(order_indices)
    f = np.load(s["forward_path"], mmap_mode="r+")
    r = np.load(s["reverse_path"], mmap_mode="r+")
    bar = tqdm(
        total=len(ci) * len(oi) * (2 if reverse else 1),
        desc="Centroid directed cache",
        disable=not progress,
    )
    try:
        for is_reverse, arr in [(False, f)] + ([(True, r)] if reverse else []):
            for c0 in range(0, len(ci), 16):
                cs = ci[c0 : c0 + 16]
                for o0 in range(0, len(oi), 48):
                    os = oi[o0 : o0 + 48]
                    if not np.isnan(arr[np.ix_(cs, os)]).any():
                        bar.update(len(cs) * len(os))
                        continue
                    cp = [tuple(s["centroids"][j]) for j in cs]
                    op = [tuple(s["orders"][j]) for j in os]
                    if not s.get("fixture"):
                        router.fallback.prefetch(
                            op if is_reverse else cp, cp if is_reverse else op
                        )
                    for c in cs:
                        for o in os:
                            if np.isnan(arr[c, o]):
                                a, b = s["centroids"][c], s["orders"][o]
                                if is_reverse:
                                    a, b = b, a
                                arr[c, o] = router.route(a, b, False).seconds
                    arr.flush()
                    bar.update(len(cs) * len(os))
    finally:
        router.close()
        bar.close()
    merge_route_deltas(spec_path)
    return {
        "forward_complete": bool(np.isfinite(f[np.ix_(ci, oi)]).all()),
        "reverse_requested": reverse,
    }


def create_search_index(distance_array, chunk_rows=1_000_000):
    """Absolute from-ID ranges; bounded RAM even for a large legacy file."""
    result = {}
    current = None
    start = 0
    for offset in range(0, len(distance_array), chunk_rows):
        ids = np.asarray(distance_array[offset : offset + chunk_rows, 0])
        cuts = np.r_[0, np.flatnonzero(ids[1:] != ids[:-1]) + 1]
        for cut in cuts:
            key = int(ids[cut])
            absolute = offset + int(cut)
            if current is not None and key != current:
                if key < current:
                    raise ValueError("Legacy array must be sorted by from ID")
                result[current] = (start, absolute)
                start = absolute
            if current is None:
                start = absolute
            current = key
    if current is not None:
        result[current] = (start, len(distance_array))
    return result
