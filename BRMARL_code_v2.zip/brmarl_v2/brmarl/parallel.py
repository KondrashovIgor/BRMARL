"""Four CPU processes x three event loops; a parent owns all neural parameters.

Worker threads suspend on inference RPC. Only the parent renders progress and
updates policies, after EVERY market in a packet has completed.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from collections import defaultdict
import copy, multiprocessing as mp, pickle, queue, threading, time, json, traceback
import numpy as np
import torch
from .environment import Market
from .cache import SecondsRouter
from .inference import NeuralBatcher
from .learning import place_agent
from .progress import MarketProgress
from .evaluation import report


class RPCClient:
    def __init__(self, worker, requests, replies, timeout):
        self.worker = worker
        self.requests = requests
        self.replies = replies
        self.timeout = timeout
        self.lock = threading.Lock()
        self.pending = {}
        self.next = 0
        self.reader = threading.Thread(target=self._read, daemon=True)
        self.reader.start()

    def _read(self):
        while True:
            batch = self.replies.get()
            if batch is None:
                return
            for token, value, error in batch:
                with self.lock:
                    slot = self.pending.get(token)
                if slot is not None:
                    slot["value"] = value
                    slot["error"] = error
                    slot["event"].set()

    def infer(self, payload):
        with self.lock:
            self.next += 1
            token = self.next
            slot = {"event": threading.Event()}
            self.pending[token] = slot
        self.requests.put(("rpc", self.worker, token, payload))
        try:
            if not slot["event"].wait(self.timeout):
                raise TimeoutError("GPU inference RPC timeout")
            if slot.get("error"):
                raise RuntimeError(slot["error"])
            return slot["value"]
        finally:
            with self.lock:
                self.pending.pop(token, None)


def _worker(
    worker_id,
    shift_ids,
    assets,
    snapshot,
    cfg,
    par,
    spec,
    output,
    requests,
    replies,
    network_lock,
    start_event,
):
    torch.set_num_threads(1)
    client = RPCClient(worker_id, requests, replies, par.rpc_timeout_s)

    def run_one(sid):
        agents = copy.deepcopy(snapshot)
        for a in agents:
            a.defer_updates = True
            a.inference_backend = client
        router = SecondsRouter(spec, network_lock)
        directory = Path(output) / f"shift_{sid:05}"
        directory.mkdir(parents=True, exist_ok=True)
        started = time.perf_counter()
        last = [0.0]
        try:
            env = Market(assets, router, agents, cfg, sid, True)

            def progress(now, phase, attempts):
                t = time.perf_counter()
                if t - last[0] > 0.25 or phase != "simulate" or now >= cfg.B:
                    requests.put(("progress", sid, now, phase, attempts))
                    last[0] = t

            env.progress_callback = progress
            router.status_callback = lambda phase: progress(
                env.now, phase, len(env.logs["tenders"])
            )
            summary = env.run()
            save_start = time.perf_counter()
            report(env, directory, False, maps_enabled=par.report_maps)
            save_wall = time.perf_counter() - save_start
            records = []
            for a in agents:
                records.append(
                    {
                        k: getattr(a, k)
                        for k in (
                            "buffer",
                            "endshift",
                            "choice_history",
                            "threshold_events",
                            "preference_events",
                            "reward_events",
                        )
                    }
                )
            result_path = directory / "experience.pkl"
            temp = result_path.with_suffix(".partial")
            with temp.open("wb") as f:
                pickle.dump(records, f, pickle.HIGHEST_PROTOCOL)
            temp.replace(result_path)
            metadata = {
                "shift": sid,
                "worker": worker_id,
                "rollout_and_save_wall_s": time.perf_counter() - started,
                "simulation_wall_s": env.timings.total["simulation_wall"],
                "finalize_wall_s": env.timings.total["finalize_wall"],
                "save_wall_s": save_wall,
                "inference_rpc_wait_s": sum(
                    getattr(a, "inference_wait_s", 0) for a in agents
                ),
                "adapter_updates_during_rollout": sum(
                    a.learning_steps - b.learning_steps
                    for a, b in zip(agents, snapshot)
                ),
                "encoder_version": snapshot[0].version,
            }
            (directory / "worker_timing.json").write_text(
                json.dumps(metadata, indent=2)
            )
            requests.put(
                ("done", sid, str(result_path), summary.to_dict("records"), metadata)
            )
        finally:
            router.close()

    try:
        requests.put(("ready", worker_id))
        if not start_event.wait(par.worker_timeout_s):
            raise TimeoutError("Worker startup barrier timeout")
        with ThreadPoolExecutor(max_workers=len(shift_ids)) as pool:
            futures = [pool.submit(run_one, sid) for sid in shift_ids]
            for f in as_completed(futures):
                f.result()
    except BaseException:
        requests.put(("error", worker_id, traceback.format_exc()))
    finally:
        replies.put(None)
        client.reader.join(timeout=5)


def rollout_packet(assets, agents, cfg, par, spec, shift_ids, output, dashboard=None):
    context = mp.get_context("spawn")
    requests = context.Queue()
    replies = [context.Queue() for _ in range(min(par.workers, len(shift_ids)))]
    network_lock = context.Lock()
    start_event = context.Event()
    ready = set()
    processes = []
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    # Copies sent to CPU processes have no CUDA contexts, RPC clients or optimizer work.
    snapshot = copy.deepcopy(agents)
    for a in snapshot:
        place_agent(a, "cpu")
        a.inference_backend = None
        a.buffer = []
        a.endshift = []
        a.choice_history = []
    device = par.device
    engine = NeuralBatcher(agents, device)
    engine.warmup(agents[0].cfg.modes, min(len(shift_ids), 12), cfg.seed)
    own_dashboard = dashboard is None
    progress = dashboard or MarketProgress(shift_ids, cfg.B, par.progress)
    if dashboard is not None:
        progress.reset(shift_ids)
    start = time.perf_counter()
    done = {}
    last_message = start
    pending = []
    all_summary = []

    def submit(items):
        if not items:
            return
        values = engine.infer_many([m[3] for m in items])
        dest = defaultdict(list)
        for m, value in zip(items, values):
            dest[m[1]].append((m[2], value, None))
        for worker, batch in dest.items():
            replies[worker].put(batch)

    try:
        for worker in range(len(replies)):
            assigned = list(shift_ids[worker :: len(replies)])
            p = context.Process(
                target=_worker,
                args=(
                    worker,
                    assigned,
                    assets,
                    snapshot,
                    cfg,
                    par,
                    str(spec),
                    str(output),
                    requests,
                    replies[worker],
                    network_lock,
                    start_event,
                ),
            )
            p.start()
            processes.append(p)
        while len(done) < len(shift_ids):
            deadline = time.perf_counter() + par.inference_wait_ms / 1000
            while len(pending) < par.max_inference_batch:
                timeout = (
                    max(0.0001, deadline - time.perf_counter()) if pending else 0.1
                )
                try:
                    message = requests.get(timeout=timeout)
                except queue.Empty:
                    break
                last_message = time.perf_counter()
                kind = message[0]
                if kind == "rpc":
                    if not pending:
                        deadline = time.perf_counter() + par.inference_wait_ms / 1000
                    pending.append(message)
                elif kind == "ready":
                    ready.add(message[1])
                    if len(ready) == len(replies):
                        start_event.set()
                elif kind == "progress":
                    progress.update(
                        message[1], message[2], message[3], attempts=message[4]
                    )
                elif kind == "done":
                    _, sid, path, summary, timing = message
                    done[sid] = {
                        "path": path,
                        "timing": timing,
                        "received_s": time.perf_counter() - start,
                    }
                    all_summary.extend(summary)
                    progress.update(sid, cfg.B, "waiting for batch")
                elif kind == "error":
                    raise RuntimeError("CPU worker failed:\n" + message[2])
                if pending and time.perf_counter() >= deadline:
                    break
            submit(pending)
            pending = []
            for p in processes:
                if p.exitcode is not None and p.exitcode != 0:
                    raise RuntimeError(f"CPU worker exited with code {p.exitcode}")
            if time.perf_counter() - last_message > par.worker_timeout_s:
                raise TimeoutError(
                    "No worker heartbeat; inspect route timeouts and worker logs"
                )
        barrier = time.perf_counter() - start
        for sid, entry in done.items():
            entry["timing"]["barrier_wait_s"] = barrier - entry["received_s"]
            Path(entry["path"]).with_name("worker_timing.json").write_text(
                json.dumps(entry["timing"], indent=2)
            )
        for p in processes:
            p.join(timeout=10)
            if p.is_alive():
                raise RuntimeError("Worker failed to exit after completing markets")
        return done, all_summary, {"rollout_barrier_wall_s": barrier, **engine.stats()}
    finally:
        if own_dashboard:
            progress.close()
        for p in processes:
            if p.is_alive():
                p.terminate()
        for p in processes:
            p.join(timeout=5)
        requests.close()
        for q in replies:
            q.close()


def merge_packet(agents, completed):
    """Deterministic market order. Never average Adam states or agent identities."""
    for a in agents:
        a.buffer = []
        a.endshift = []
        a.choice_history = []
    for sid in sorted(completed):
        with open(completed[sid]["path"], "rb") as f:
            records = pickle.load(f)
        for a, r in zip(agents, records):
            a.buffer.extend(r["buffer"])
            a.endshift.extend(r["endshift"])
            a.choice_history.extend(r["choice_history"])
            for key, y, x, critical_id in r["threshold_events"]:
                a.bank.observe(key, y, x, critical_id)
            for pid, winner, loser in r["preference_events"]:
                a.preference.observe(pid, winner, loser)
            for key, reward in r["reward_events"]:
                old = a.al.get(key, 50.0)
                a.al[key] = (1 - a.cfg.al_lr) * old + a.cfg.al_lr * reward
                a.scale = 0.99 * a.scale + 0.01 * abs(reward - old)
