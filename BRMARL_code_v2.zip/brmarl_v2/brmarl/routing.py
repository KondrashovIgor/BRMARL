import json, sqlite3, time, urllib.request, urllib.parse
from dataclasses import dataclass
import numpy as np


class RoutingError(RuntimeError):
    pass


def haversine(a, b):
    la, lo, lb, lob = np.radians([*a, *b])
    q = (
        np.sin((lb - la) / 2) ** 2
        + np.cos(la) * np.cos(lb) * np.sin((lob - lo) / 2) ** 2
    )
    return float(6371000 * 2 * np.arcsin(np.sqrt(min(1, q))))


def offset_point(point, radius_m, rng):
    r = radius_m * np.sqrt(rng.random())
    angle = rng.uniform(0, 2 * np.pi)
    return (
        float(point[0] + r * np.cos(angle) / 111320),
        float(point[1] + r * np.sin(angle) / (111320 * np.cos(np.radians(point[0])))),
    )


@dataclass
class Route:
    seconds: float
    meters: float
    points: list
    source: str


class OSRMRouter:
    """Persistent directed OD cache; no Euclidean fallback on OSRM errors."""

    source = "OSRM"

    def __init__(
        self,
        cache_path,
        base_url="https://router.project-osrm.org",
        profile="driving",
        timeout=25,
        min_interval=0.15,
    ):
        self.url = base_url.rstrip("/")
        self.profile = profile
        self.timeout = timeout
        self.interval = min_interval
        self.last = 0.0
        self.db = sqlite3.connect(str(cache_path))
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS routes (k TEXT PRIMARY KEY, payload TEXT)"
        )
        self.hits = 0
        self.calls = 0

    def key(self, a, b):
        return json.dumps(
            [
                self.url,
                self.profile,
                [round(float(v), 6) for v in a],
                [round(float(v), 6) for v in b],
            ]
        )

    def _get(self, path):
        delay = self.interval - (time.monotonic() - self.last)
        if delay > 0:
            time.sleep(delay)
        self.last = time.monotonic()
        self.calls += 1
        try:
            req = urllib.request.Request(
                self.url + path, headers={"User-Agent": "BRMARL-research-prototype/0.1"}
            )
            with urllib.request.urlopen(req, timeout=self.timeout) as f:
                out = json.load(f)
        except Exception as e:
            raise RoutingError(f"OSRM request failed: {type(e).__name__}: {e}") from e
        if out.get("code") != "Ok":
            raise RoutingError(f'OSRM {out.get("code")}: {out.get("message","")}')
        return out

    def route(self, a, b, geometry=True):
        if haversine(a, b) < 0.1:
            return Route(0.0, 0.0, [list(a), list(b)], self.source)
        k = self.key(a, b)
        row = self.db.execute("SELECT payload FROM routes WHERE k=?", (k,)).fetchone()
        if row:
            d = json.loads(row[0])
            if not geometry or d.get("points"):
                self.hits += 1
                return Route(**d)
        coords = f"{a[1]:.7f},{a[0]:.7f};{b[1]:.7f},{b[0]:.7f}"
        r = self._get(
            f'/route/v1/{self.profile}/{coords}?overview={"full" if geometry else "false"}&geometries=geojson'
        )["routes"][0]
        points = (
            [[lat, lon] for lon, lat in r.get("geometry", {}).get("coordinates", [])]
            if geometry
            else []
        )
        out = Route(float(r["duration"]), float(r["distance"]), points, self.source)
        self.db.execute(
            "INSERT OR REPLACE INTO routes VALUES (?,?)", (k, json.dumps(out.__dict__))
        )
        self.db.commit()
        return out

    def prefetch(self, sources, targets):
        sources = list(dict.fromkeys(tuple(x) for x in sources))
        targets = list(dict.fromkeys(tuple(x) for x in targets))
        missing = [
            (a, b)
            for a in sources
            for b in targets
            if not self.db.execute(
                "SELECT 1 FROM routes WHERE k=?", (self.key(a, b),)
            ).fetchone()
        ]
        if not missing:
            return
        coords = list(dict.fromkeys(sources + targets))
        idx = {p: i for i, p in enumerate(coords)}
        if len(coords) > 80:
            for a, b in missing:
                self.route(a, b, False)
            return
        string = ";".join(f"{p[1]:.7f},{p[0]:.7f}" for p in coords)
        query = urllib.parse.urlencode(
            {
                "sources": ";".join(str(idx[a]) for a in sources),
                "destinations": ";".join(str(idx[b]) for b in targets),
                "annotations": "duration,distance",
            }
        )
        out = self._get(f"/table/v1/{self.profile}/{string}?{query}")
        for i, a in enumerate(sources):
            for j, b in enumerate(targets):
                secs = out["durations"][i][j]
                meters = out["distances"][i][j]
                if secs is None or meters is None:
                    continue
                k = self.key(a, b)
                self.db.execute(
                    "INSERT OR IGNORE INTO routes VALUES (?,?)",
                    (
                        k,
                        json.dumps(
                            Route(float(secs), float(meters), [], self.source).__dict__
                        ),
                    ),
                )
        self.db.commit()

    def nearest(self, p):
        r = self._get(f"/nearest/v1/{self.profile}/{p[1]:.7f},{p[0]:.7f}?number=1")[
            "waypoints"
        ][0]["location"]
        return (float(r[1]), float(r[0]))

    def close(self):
        self.db.close()


class FixtureRouter:
    """Deterministic synthetic router for tests only, explicitly labelled in logs."""

    source = "SYNTHETIC_ROUTER"

    def __init__(self, speed_m_s=8):
        self.speed = speed_m_s
        self.calls = 0
        self.hits = 0

    def route(self, a, b, geometry=True):
        meters = haversine(a, b) * 1.25
        return Route(
            meters / self.speed,
            meters,
            [list(a), list(b)] if geometry else [],
            self.source,
        )

    def prefetch(self, *args):
        pass

    def nearest(self, p):
        return tuple(p)

    def close(self):
        pass


def position_along(route, fraction):
    pts = np.asarray(route.points, float)
    if len(pts) == 0:
        raise RoutingError("No geometry for physical position")
    if len(pts) == 1:
        return tuple(pts[0])
    distances = np.array([haversine(a, b) for a, b in zip(pts[:-1], pts[1:])])
    total = distances.sum()
    if total <= 0:
        return tuple(pts[-1])
    x = np.clip(fraction, 0, 1) * total
    cs = np.r_[0, np.cumsum(distances)]
    i = min(len(distances) - 1, int(np.searchsorted(cs, x, side="right") - 1))
    f = (x - cs[i]) / max(distances[i], 1e-9)
    return tuple(pts[i] * (1 - f) + pts[i + 1] * f)
