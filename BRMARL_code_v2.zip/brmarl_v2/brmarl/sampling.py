from dataclasses import dataclass, field
import numpy as np
from scipy.special import expit
from scipy.optimize import brentq
from scipy.stats import truncnorm


@dataclass
class Order:
    order_id: str
    pid: str
    centroid: tuple
    client: tuple
    theta: tuple
    service_s: float
    initial_U: float
    U: float
    created_s: float
    attempt: int = 0
    history: list = field(default_factory=list)


class ArrivalProcess:
    """Positive, integer-minute logistic waiting times, calibrated by renewal mean."""

    def __init__(self, cfg):
        self.cfg = cfg
        mean_batch = (cfg.batch_min + cfg.batch_max) / 2
        desired = cfg.B / 60 * mean_batch / cfg.target_new_orders
        if desired < 1:
            raise ValueError("Requested arrival rate exceeds one event per minute")
        self.target_interval_min = desired

        def mean_wait(loc):
            grid = np.arange(0, max(200, int(desired * 30)))
            return float(
                np.sum(
                    (1 - expit((grid - loc) / cfg.arrival_scale_min))
                    / (1 - expit(-loc / cfg.arrival_scale_min))
                )
            )

        self.location_min = brentq(
            lambda loc: mean_wait(loc) - desired, -30, max(100, desired * 4)
        )

    def sample_interval(self, rng):
        f0 = expit(-self.location_min / self.cfg.arrival_scale_min)
        u = f0 + (1 - f0) * rng.random()
        raw = self.location_min + self.cfg.arrival_scale_min * np.log(u / (1 - u))
        return max(1, int(np.ceil(raw))) * 60.0

    def schedule(self, rng):
        result = []
        t = 0.0
        count = 0
        while True:
            t += self.sample_interval(rng)
            if t >= self.cfg.B or count >= self.cfg.cap_new_orders:
                break
            n = min(
                int(rng.integers(self.cfg.batch_min, self.cfg.batch_max + 1)),
                self.cfg.cap_new_orders - count,
            )
            result.append((t, n))
            count += n
        return result


def sample_order(assets, rng, cfg, order_id, time_s):
    rec = assets["polygons"][int(rng.integers(len(assets["polygons"])))]
    pts = rec["points"]
    u = float(rng.uniform(cfg.initial_U_min, cfg.initial_U_max))
    return Order(
        str(order_id),
        rec["pid"],
        tuple(rec["centroid"]),
        tuple(pts[int(rng.integers(len(pts)))]),
        tuple(rec["theta"]),
        float(rng.uniform(cfg.service_min_s, cfg.service_max_s)),
        u,
        u,
        float(time_s),
    )


def reprice(last, rng, cap):
    return min(cap, float(last + abs(rng.normal()) * max(0.0, cap - last) / 2))


def break_probability(continuous_work_s, cfg):
    return float(expit((continuous_work_s - cfg.B / 4) / cfg.break_hazard_scale_s))


def break_duration(rng, cfg):
    a = (cfg.break_min_s - cfg.break_mean_s) / cfg.break_std_s
    b = (cfg.break_max_s - cfg.break_mean_s) / cfg.break_std_s
    return float(
        truncnorm.rvs(
            a, b, loc=cfg.break_mean_s, scale=cfg.break_std_s, random_state=rng
        )
    )
