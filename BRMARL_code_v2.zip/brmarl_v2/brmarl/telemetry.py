"""Exclusive phase timers and bounded per-operation latency samples."""

from contextlib import contextmanager
from collections import defaultdict, deque
import time, json
import numpy as np


class Timings:
    def __init__(self):
        self.total = defaultdict(float)
        self.count = defaultdict(int)
        self.samples = defaultdict(lambda: deque(maxlen=4096))

    def add(self, name, seconds):
        self.total[name] += seconds
        self.count[name] += 1
        self.samples[name].append(seconds)

    @contextmanager
    def measure(self, name):
        t = time.perf_counter()
        try:
            yield
        finally:
            self.add(name, time.perf_counter() - t)

    def snapshot(self):
        return {
            k: {
                "total_s": v,
                "calls": self.count[k],
                "p50_s": float(np.median(self.samples[k])),
                "p95_s": float(np.quantile(self.samples[k], 0.95)),
            }
            for k, v in self.total.items()
        }

    def save(self, path):
        with open(path, "w") as f:
            json.dump(self.snapshot(), f, indent=2)


def timed_method(name):
    def decorate(fn):
        def call(self, *args, **kwargs):
            with self.timings.measure(name):
                return fn(self, *args, **kwargs)

        return call

    return decorate
