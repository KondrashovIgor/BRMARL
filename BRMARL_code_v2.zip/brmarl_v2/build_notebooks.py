from pathlib import Path
import nbformat as nbf

ROOT = Path(__file__).resolve().parent
md = nbf.v4.new_markdown_cell
code = nbf.v4.new_code_cell
setup = """from pathlib import Path
import os, sys, json, time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display, IFrame
ROOT=Path.cwd()
assert (ROOT/'brmarl').is_dir(), 'Запустите notebook из распакованного проекта'
sys.path.insert(0,str(ROOT))
from brmarl.config import MarketConfig, AgentConfig, ParallelConfig
from brmarl.data import (load_assets, make_fixture_assets, prepare_route_cache,
                         create_search_index, prewarm_centroid_pool)
from brmarl.experiment import train, test, load_checkpoint
from brmarl.evaluation import refusal_metrics
MODE=os.environ.get('BRMARL_MODE','original')
assert MODE in ('original','fixture')
FIXTURE=MODE=='fixture'
DATA_ROOT=Path(os.environ.get('BRMARL_DATA_ROOT',ROOT/'data'))
DATA={'properties':'global_properties_osrm_seconds.pkl','map':'AUG_global_map_osrm_seconds.pkl',
      'results':'epos_cache_fd.pkl','couriers':'courier_training_checkpoint_fd_seconds.pkl',
      'preferences':'glob_pref_map.pkl'}
if FIXTURE:
    assets=make_fixture_assets(ROOT/'data/fixture.json')
else:
    normalized=DATA_ROOT/'brmarl_assets.json'
    assets=load_assets(normalized,config=MarketConfig()) if normalized.exists() else load_assets(
        DATA_ROOT/DATA['map'],DATA_ROOT/DATA['preferences'],config=MarketConfig())
print('MODE:',MODE,'source:',assets['source'])
print('polygons:',len(assets['polygons']),'order columns:',sum(len(p['points']) for p in assets['polygons']))
"""
config = """market_cfg=MarketConfig(seed=42,B=43200,n_couriers=10,target_new_orders=300,cap_new_orders=300,
    expected_original_polygons=None if FIXTURE else 385,
    expected_order_points=None if FIXTURE else 20160)
agent_cfg=AgentConfig(seed=42,model_adv_weight=0.)
parallel_cfg=ParallelConfig(workers=4,markets_per_batch=12,device='auto',progress=True)
N_TRAIN_BATCHES=int(os.environ.get('BRMARL_TRAIN_BATCHES','20'))
TRAIN_DIR=ROOT/'outputs'/MODE/'train'
CACHE_ROOT=(ROOT/'outputs'/MODE/'routes') if FIXTURE else DATA_ROOT/'brmarl_route_cache'
print('Batches:',N_TRAIN_BATCHES,'total markets:',N_TRAIN_BATCHES*parallel_cfg.markets_per_batch)
"""
cache = """# Выполняется до создания CPU-процессов. Можно передать уже открытые переменные
# distance_array (memmap), idx_dict и coordinate_to_id из исходного notebook.
prep_start=time.perf_counter()
legacy=None;index=None
if not FIXTURE:
    if 'distance_array' in globals() and 'idx_dict' in globals():
        legacy=distance_array;index=idx_dict
    elif not (CACHE_ROOT/'route_spec.json').exists():
        distance_path=Path(os.environ.get('BRMARL_DISTANCE_FILE',DATA_ROOT/'distances.dat'))
        if not distance_path.exists():raise FileNotFoundError('Нужен существующий distances.dat или готовый route_spec.json')
        assert distance_path.stat().st_size%12==0, 'Ожидается raw int32 [from,to,seconds]'
        legacy=np.memmap(distance_path,dtype=np.int32,mode='r',shape=(distance_path.stat().st_size//12,3))
        index=create_search_index(legacy)
ROUTE_SPEC=prepare_route_cache(assets,CACHE_ROOT,legacy,index,
    coordinate_to_id=globals().get('coordinate_to_id'),fixture=FIXTURE,config=market_cfg)
route_info=json.loads(Path(ROUTE_SPEC).read_text())
print('Directed centroid maps:',route_info['shape_centroids'],'each; unknown=NaN')
print('Legacy array:',route_info.get('distance_path'))
print('Cache preparation seconds:',round(time.perf_counter()-prep_start,3))
"""
train_cells = [
    md(
        """# BRMARL v2 — синхронное пакетное обучение

4 CPU-процесса обслуживают 12 рынков; один родитель владеет GPU и пакетирует neural inference.
Индивидуальные политики десяти курьеров реплицируются между рынками. Все neural weights, CFR и OSR
фиксированы до завершения последней смены пакета. Затем — одно полное actor-обновление на агента,
обучение контекста и обновление библиотек. Online-адаптация вынесена в отдельный тест.

По умолчанию **original**: 385 полигонов, 20160 столбцов заказов и существующий направленный seconds memmap.
Сохранённые fixture outputs — только инженерный прогон. Для Windows/Jupyter workers находятся в .py,
используется spawn; notebook не содержит функций, которые нужно сериализовать в дочерний процесс."""
    ),
    code(setup),
    code(config),
    md(
        """## Кэш маршрутов до запуска работников

`point_ids` из исходного `full map` связывают координаты с абсолютными ID memmap. Для старого normalized JSON
переэкспортируйте assets или передайте coordinate_to_id. Штрафов между полигонами нет.

Создаются два отдельных файла одинаковой формы [centroid, order]:
forward[c,o] = centroid[c]→order[o], reverse[c,o] = order[o]→centroid[c]. Значения не транспонируются.
Работники открывают их read-only; дополнения попадают в общий SQLite WAL и сливаются родителем после барьера.
Неизвестные пары идут в существующий cache/OSRM. Продолжительность исполнения — два фактических времени маршрута."""
    ),
    code(cache),
    md(
        """## Необязательное предварительное заполнение выбранного пула

Создание файлов не означает 7.76 млн серверных запросов. По умолчанию выделяются файлы с NaN,
а неизвестные значения заполняются по мере использования. Полный prewarm — отдельная потенциально долгая фаза.
Для частичного заполнения укажите индексы ORDER_POOL и CENTROID_POOL. Обе стороны направления независимы.
На большой карте предпочтителен ваш локальный OSRM. Повторный запуск использует уже заполненные клетки."""
    ),
    code("""PREWARM_ALL=False
CENTROID_POOL=None
ORDER_POOL=None
if PREWARM_ALL or ORDER_POOL is not None:
    display(prewarm_centroid_pool(ROUTE_SPEC,CENTROID_POOL,ORDER_POOL,reverse=True,progress=True))
"""),
    md(
        """## Пакеты смен

12 progress bars принадлежат только родителю. В терминале позиции фиксированы, в Jupyter используются widgets.
Модельные часы доходят до B, затем отдельно показываются завершение обязательств, ожидание барьера и learning.
Слоты переиспользуются в следующем пакете. Для файлового stdout bars отключаются.

Теневые цены busy-курьера исходят из последней завершённой/послеперерывной точки. Это гипотеза
о пропуске текущего обязательства, а не его фактическое положение и не достоверная альтернативная смена.
Такие метки не обучают допустимое участие. Реальный победитель обязан исполнить заказ."""
    ),
    code(
        """agents,training_summary=train(assets,market_cfg,agent_cfg,n_batches=N_TRAIN_BATCHES,
    output=TRAIN_DIR,fixture=FIXTURE,parallel_cfg=parallel_cfg,route_spec=ROUTE_SPEC)
display(training_summary.groupby('batch')[['completed','net_profit','break_cost','return_cost']].sum())
"""
    ),
    code("""timings=json.loads((TRAIN_DIR/'batch_timings.json').read_text())
display(pd.DataFrame([{k:v for k,v in row.items() if k!='agent_updates'} for row in timings]))
display(pd.DataFrame([dict(batch=row['batch'],courier=i,**update)
    for row in timings for i,update in enumerate(row['agent_updates'])]))
print('Checkpoint:',TRAIN_DIR/'checkpoint.pt')
print('Наблюдайте mean_agent_batch: microbatch size зависит от готовности рынков, не обязан равняться 12.')
"""),
    md("""## Продолжение

`train(..., resume=TRAIN_DIR/'checkpoint.pt', n_batches=...)` добавляет пакеты к существующему checkpoint.
Checkpoint сохраняется после каждого полного пакета; v1 checkpoint не загружается молча.
Число рынков — бюджет данных, число пакетов — бюджет обновлений. Качество определяется в отдельных тестах,
по seed, калибровке порога, AL и абляциям; двадцать пакетов не являются критерием сходимости.

Все журналы сохранены по batch/shift. В новых логах positions — зафиксированные точки отправления,
а карты показывают endpoint schematics, а не физическую дорожную геометрию."""),
]

test_cells = [
    md(
        """# BRMARL v2 — frozen holdout и отдельная online-адаптация

Каждый режим заново загружает один checkpoint. Frozen не меняет параметры; online обновляет BRMARL внутри
смены, используя предобученные context/OSR/CFR, фиксированные до конца этой смены. Между online-сменами
разрешены послесменные обновления. Истинные клиентские theta доступны только механизму аукциона."""
    ),
    code(setup),
    code("""TRAIN_DIR=ROOT/'outputs'/MODE/'train'
CHECKPOINT=TRAIN_DIR/'checkpoint.pt'
saved=load_checkpoint(CHECKPOINT,assets)
local_cache=(ROOT/'outputs'/MODE/'routes') if FIXTURE else DATA_ROOT/'brmarl_route_cache'
ROUTE_SPEC=prepare_route_cache(assets,local_cache,fixture=FIXTURE,config=MarketConfig(**saved['market']))
N_TEST_SHIFTS=int(os.environ.get('BRMARL_TEST_SHIFTS','2'))
print('Training packets:',saved['n_training_batches'],'markets:',saved['n_training_shifts'])
"""),
    md("""## Полностью замороженный holdout

Новые seed, без адаптации весов, AL и threshold bank. Кэш маршрутов может дополняться,
но не передаёт агенту скрытые предпочтения или будущие исходы."""),
    code("""frozen_envs,frozen_summary=test(assets,CHECKPOINT,n_shifts=N_TEST_SHIFTS,
    output=ROOT/'outputs'/MODE/'test_frozen',adaptive=False,fixture=FIXTURE,
    route_spec=ROUTE_SPEC,shap_enabled=False,device='cpu',progress=True)
display(frozen_summary)
"""),
    md("""## Отдельный prequential online-тест

Здесь BRMARL обновляется после раскрытия доступной обратной связи, без доступа к другим тестовым мирам.
Это другой протокол, чем offline packet training. Начальные seed совпадают с frozen; после разных решений
эндогенные траектории могут расходиться. Начальный checkpoint загружается заново."""),
    code("""RUN_ONLINE_TEST=True
if RUN_ONLINE_TEST:
    online_envs,online_summary=test(assets,CHECKPOINT,n_shifts=N_TEST_SHIFTS,
        output=ROOT/'outputs'/MODE/'test_online',adaptive=True,fixture=FIXTURE,
        route_spec=ROUTE_SPEC,shap_enabled=True,device='cpu',progress=True)
    display(online_summary)
"""),
    code("""metrics=[]
for mode,envs in [('frozen',frozen_envs)]+([('online',online_envs)] if RUN_ONLINE_TEST else []):
    for k,env in enumerate(envs):metrics.append(dict(mode=mode,shift=k,**refusal_metrics(env)))
metrics=pd.DataFrame(metrics)
display(metrics.drop(columns=['interpretation'],errors='ignore'))
cols=['primary_affordable_policy_skips','primary_affordable_selected_other',
      'primary_affordable_price_infeasible','primary_affordable_unavailable']
display(metrics[['mode','shift']+cols])
metrics.set_index(['mode','shift'])[cols].plot.bar(figsize=(12,4));plt.tight_layout()
"""),
    md("""## Журналы, карта и SHAP

Первичный policy skip считается отдельно от занятости, выбора другого заказа и полной ценовой
неосуществимости. Маркер отказов не доказывает сговора. Карта ниже — схема точек отправления/прибытия.
Физическое перемещение внутри обязательства не моделируется.

SHAP объясняет BRMARL pricing head на конец смены при фиксированных context/latent/memory.
Если нет подходящих BRMARL-наблюдений, selection явно помечает альтернативный head probe на CFR-контекстах.
Это не объяснение gate, участия, исторических весов или причинных эффектов."""),
    code("""mode='test_online' if RUN_ONLINE_TEST else 'test_frozen'
last_dir=ROOT/'outputs'/MODE/mode/f'shift_{N_TEST_SHIFTS-1:03}'
print(json.loads((last_dir/'checks.json').read_text()))
print(json.loads((last_dir/'timings.json').read_text()))
display(IFrame(str((last_dir/'trajectory_map.html').relative_to(ROOT)),width='100%',height=500))
if (last_dir/'shap_status.json').exists():
    print(json.loads((last_dir/'shap_status.json').read_text()))
    if (last_dir/'shap_price.csv').exists():display(pd.read_csv(last_dir/'shap_price.csv').head(20))
display(pd.read_csv(last_dir/'awards.csv').head(20))
"""),
]
for name, cells in [
    ("01_train_brmarl.ipynb", train_cells),
    ("02_test_brmarl.ipynb", test_cells),
]:
    nb = nbf.v4.new_notebook(
        cells=cells,
        metadata={
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            }
        },
    )
    nbf.write(nb, ROOT / name)
print("Built v2 notebooks")
